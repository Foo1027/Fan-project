"""
商品信息分析 Agent
负责提取和结构化商品信息
"""

from typing import Dict, List, Optional, Any
import json
import uuid
from loguru import logger

from .base_agent import BaseAgent
from ..models.product import Product, ProductAttribute, ProductCategory
from ..tools.llm_client import LLMClient


class ProductAnalyzer(BaseAgent):
    """
    商品信息分析 Agent
    
    功能：
    1. 从原始数据中提取商品信息
    2. 识别核心卖点
    3. 分析目标受众
    4. 生成商品标签
    """
    
    def __init__(self, llm_client: Optional[LLMClient] = None, config: Optional[Dict[str, Any]] = None):
        super().__init__("ProductAnalyzer", config)
        self.llm = llm_client or LLMClient()
    
    async def process(self, input_data: Any, **kwargs) -> Product:
        """
        分析商品信息
        
        Args:
            input_data: 可以是商品文本描述、URL、或部分商品数据
            **kwargs: 
                - product_id: 商品ID（可选）
                - source_type: 数据来源类型（text/url/json）
        
        Returns:
            Product 对象
        """
        source_type = kwargs.get("source_type", "auto")
        product_id = kwargs.get("product_id", str(uuid.uuid4())[:8])
        
        logger.info(f"Analyzing product from {source_type} source")
        
        # 根据输入类型解析
        if isinstance(input_data, dict):
            product_data = input_data
        elif isinstance(input_data, str):
            if source_type == "url" or input_data.startswith("http"):
                product_data = await self._extract_from_url(input_data)
            else:
                product_data = await self._extract_from_text(input_data)
        else:
            raise ValueError(f"Unsupported input type: {type(input_data)}")
        
        # 使用 LLM 增强分析
        enhanced_data = await self._enhance_with_llm(product_data)
        
        # 构建 Product 对象
        product = self._build_product(product_id, enhanced_data)
        
        logger.success(f"Product analysis completed: {product.name}")
        return product
    
    async def _extract_from_url(self, url: str) -> Dict[str, Any]:
        """从 URL 提取商品信息（简化版）"""
        # 实际项目中这里应该使用爬虫或 API
        logger.info(f"Extracting from URL: {url}")
        # 返回模拟数据
        return {
            "source_url": url,
            "name": "从URL提取的商品",
            "description": "需要实现具体的爬虫逻辑",
        }
    
    async def _extract_from_text(self, text: str) -> Dict[str, Any]:
        """从文本提取商品信息"""
        logger.info("Extracting from text description")
        return {
            "raw_text": text,
            "description": text,
        }
    
    async def _enhance_with_llm(self, product_data: Dict[str, Any]) -> Dict[str, Any]:
        """使用 LLM 增强商品信息分析"""
        
        prompt = self._build_analysis_prompt(product_data)
        
        try:
            response = await self.llm.generate(
                prompt=prompt,
                temperature=0.3,
                max_tokens=2000,
            )
            
            # 解析 LLM 返回的 JSON
            enhanced = self._parse_llm_response(response)
            
            # 合并原始数据和增强数据
            return {**product_data, **enhanced}
            
        except Exception as e:
            logger.error(f"LLM enhancement failed: {e}")
            return product_data
    
    def _build_analysis_prompt(self, product_data: Dict[str, Any]) -> str:
        """构建分析提示词"""
        
        raw_text = product_data.get("raw_text", "")
        description = product_data.get("description", "")
        
        prompt = f"""请分析以下商品信息，提取结构化数据并以JSON格式返回：

商品描述：
{raw_text or description}

请提取以下信息（JSON格式）：
{{
    "name": "商品名称",
    "category": "商品类别（electronics/clothing/food/home/beauty/sports/books/other）",
    "price": "价格（数字）",
    "original_price": "原价（数字，可选）",
    "brand": "品牌名称",
    "features": ["核心卖点1", "核心卖点2", "核心卖点3"],
    "attributes": [
        {{"name": "属性名", "value": "属性值", "category": "属性分类"}}
    ],
    "target_audience": "目标受众描述",
    "use_cases": ["使用场景1", "使用场景2"],
    "tags": ["标签1", "标签2", "标签3"]
}}

注意：
1. 只返回JSON，不要其他文字
2. 如果信息不确定，请合理推测
3. features 至少提取3个核心卖点
4. 目标受众要具体，包含年龄、职业、需求等
"""
        return prompt
    
    def _parse_llm_response(self, response: str) -> Dict[str, Any]:
        """解析 LLM 返回的 JSON"""
        try:
            # 尝试直接解析
            return json.loads(response)
        except json.JSONDecodeError:
            # 尝试从文本中提取 JSON
            try:
                start = response.find("{")
                end = response.rfind("}") + 1
                if start >= 0 and end > start:
                    return json.loads(response[start:end])
            except:
                pass
            
            logger.warning("Failed to parse LLM response as JSON")
            return {}
    
    def _build_product(self, product_id: str, data: Dict[str, Any]) -> Product:
        """构建 Product 对象"""
        
        # 解析属性
        attributes = []
        for attr in data.get("attributes", []):
            attributes.append(ProductAttribute(
                name=attr.get("name", ""),
                value=attr.get("value", ""),
                category=attr.get("category")
            ))
        
        # 解析类别
        category_str = data.get("category", "other").lower()
        try:
            category = ProductCategory(category_str)
        except ValueError:
            category = ProductCategory.OTHER
        
        # 解析价格
        price = data.get("price", 0)
        if isinstance(price, str):
            price = float(price.replace(",", "").replace("¥", "").replace("元", ""))
        
        original_price = data.get("original_price")
        if isinstance(original_price, str):
            original_price = float(original_price.replace(",", "").replace("¥", "").replace("元", ""))
        
        return Product(
            id=product_id,
            name=data.get("name", "未命名商品"),
            description=data.get("description"),
            category=category,
            price=price,
            original_price=original_price,
            brand=data.get("brand"),
            features=data.get("features", []),
            attributes=attributes,
            target_audience=data.get("target_audience"),
            use_cases=data.get("use_cases", []),
            tags=data.get("tags", []),
            source_url=data.get("source_url"),
        )
    
    async def analyze_competitors(self, product: Product, competitor_texts: List[str]) -> Dict[str, Any]:
        """
        分析竞品信息，找出差异化卖点
        
        Args:
            product: 当前商品
            competitor_texts: 竞品描述列表
            
        Returns:
            差异化分析结果
        """
        prompt = f"""分析以下商品与竞品的差异，找出独特的卖点：

我们的商品：
{product.to_prompt_text()}

竞品信息：
"""
        for i, comp in enumerate(competitor_texts, 1):
            prompt += f"\n竞品{i}:\n{comp}\n"
        
        prompt += """
请分析：
1. 我们商品的核心差异化优势（3-5点）
2. 相比竞品的独特卖点
3. 建议强调的核心信息
4. 潜在的营销角度

以JSON格式返回：
{
    "differentiation_points": ["优势1", "优势2", "优势3"],
    "unique_selling_points": ["卖点1", "卖点2"],
    "key_messages": ["核心信息1", "核心信息2"],
    "marketing_angles": ["角度1", "角度2"]
}
"""
        
        response = await self.llm.generate(prompt=prompt, temperature=0.4)
        return self._parse_llm_response(response)