"""
图像生成 Agent
负责生成商品配图、海报等视觉内容
"""

from typing import Dict, List, Optional, Any
import uuid
import os
from datetime import datetime
from loguru import logger

from .base_agent import BaseAgent
from ..models.product import Product
from ..models.content import ContentPiece, GeneratedImage, ContentSet
from ..tools.image_client import ImageClient


class ImageGeneratorAgent(BaseAgent):
    """
    图像生成 Agent
    
    功能：
    1. 根据商品信息生成配图
    2. 根据文案生成场景图
    3. 生成营销海报
    4. 支持多种风格和尺寸
    """
    
    # 图像风格预设
    IMAGE_STYLES = {
        "product": "专业产品摄影风格，白色背景，高清细节，商业广告质感",
        "lifestyle": "生活方式摄影，自然光线，真实场景，温暖氛围",
        "minimal": "极简主义风格，大量留白，简洁构图，高级感",
        "luxury": "奢华高端风格，精致光影，质感突出，尊贵氛围",
        "tech": "科技感风格，冷色调，未来感，数字化元素",
        "warm": "温馨暖色调，柔和光线，家庭氛围，亲切感",
    }
    
    # 图像尺寸预设
    IMAGE_SIZES = {
        "square": (1024, 1024),      # 1:1  社交媒体
        "portrait": (1024, 1536),    # 2:3  小红书/Instagram
        "landscape": (1536, 1024),   # 3:2  横幅广告
        "banner": (1920, 1080),      # 16:9 网站横幅
        "story": (1080, 1920),       # 9:16 短视频/Stories
    }
    
    def __init__(self, image_client: Optional[ImageClient] = None, config: Optional[Dict[str, Any]] = None):
        super().__init__("ImageGeneratorAgent", config)
        self.image_client = image_client or ImageClient()
        self.output_dir = config.get("output_dir", "./output/images") if config else "./output/images"
        
        # 确保输出目录存在
        os.makedirs(self.output_dir, exist_ok=True)
    
    async def process(self, input_data: Any, **kwargs) -> List[GeneratedImage]:
        """
        生成图像
        
        Args:
            input_data: Product 或 ContentPiece 对象
            **kwargs:
                - style: 图像风格
                - size: 图像尺寸
                - count: 生成数量
                - content_piece: 关联的文案（可选）
        
        Returns:
            GeneratedImage 列表
        """
        style = kwargs.get("style", "product")
        size = kwargs.get("size", "square")
        count = kwargs.get("count", 1)
        content_piece = kwargs.get("content_piece")
        
        logger.info(f"Generating {count} image(s) with style: {style}, size: {size}")
        
        images = []
        for i in range(count):
            image = await self._generate_single_image(
                input_data, style, size, content_piece, index=i
            )
            images.append(image)
        
        logger.success(f"Generated {len(images)} image(s)")
        return images
    
    async def generate_for_content_set(self, product: Product, content_set: ContentSet, 
                                       **kwargs) -> ContentSet:
        """
        为内容集合生成配套图像
        
        Args:
            product: 商品对象
            content_set: 内容集合
            **kwargs: 生成参数
            
        Returns:
            更新后的 ContentSet
        """
        logger.info(f"Generating images for content set: {content_set.name}")
        
        # 生成主图（产品图）
        main_images = await self.process(
            product, 
            style="product", 
            size="square",
            count=1
        )
        content_set.images.extend(main_images)
        
        # 生成场景图（基于故事文案）
        if content_set.story:
            lifestyle_images = await self.process(
                product,
                style="lifestyle",
                size="landscape",
                count=1,
                content_piece=content_set.story
            )
            content_set.images.extend(lifestyle_images)
        
        # 生成社交媒体图
        social_images = await self.process(
            product,
            style="minimal" if content_set.primary_style.value == "minimal" else "lifestyle",
            size="portrait",
            count=2
        )
        content_set.images.extend(social_images)
        
        return content_set
    
    async def _generate_single_image(self, input_data: Any, style: str, size: str,
                                     content_piece: Optional[ContentPiece] = None,
                                     index: int = 0) -> GeneratedImage:
        """生成单张图像"""
        
        # 构建提示词
        prompt = self._build_image_prompt(input_data, style, content_piece)
        
        # 获取尺寸
        width, height = self.IMAGE_SIZES.get(size, (1024, 1024))
        
        # 生成图像
        try:
            image_result = await self.image_client.generate(
                prompt=prompt,
                width=width,
                height=height,
            )
            
            # 保存图像
            image_id = f"IMG-{str(uuid.uuid4())[:8]}"
            local_path = os.path.join(self.output_dir, f"{image_id}.png")
            
            if image_result.get("local_path"):
                # 如果客户端已保存，复制到我们的目录
                import shutil
                shutil.copy(image_result["local_path"], local_path)
            elif image_result.get("url"):
                # 下载图像
                await self._download_image(image_result["url"], local_path)
            
            # 确定关联的商品ID
            product_id = ""
            if isinstance(input_data, Product):
                product_id = input_data.id
            elif content_piece:
                product_id = content_piece.product_id
            
            return GeneratedImage(
                id=image_id,
                url=image_result.get("url"),
                local_path=local_path,
                prompt=prompt,
                style=style,
                product_id=product_id,
                content_id=content_piece.id if content_piece else None,
            )
            
        except Exception as e:
            logger.error(f"Image generation failed: {e}")
            # 返回一个占位图像对象
            return GeneratedImage(
                id=f"IMG-FAILED-{index}",
                prompt=prompt,
                style=style,
                product_id=product_id if isinstance(input_data, Product) else "",
            )
    
    def _build_image_prompt(self, input_data: Any, style: str, 
                           content_piece: Optional[ContentPiece] = None) -> str:
        """构建图像生成提示词"""
        
        style_desc = self.IMAGE_STYLES.get(style, self.IMAGE_STYLES["product"])
        
        if isinstance(input_data, Product):
            # 基于商品信息构建提示词
            prompt_parts = [
                f"商品：{input_data.name}",
                f"类别：{input_data.category.value}",
                f"品牌：{input_data.brand or '未知'}",
            ]
            
            if input_data.features:
                prompt_parts.append(f"特点：{', '.join(input_data.features[:3])}")
            
            if input_data.use_cases:
                prompt_parts.append(f"场景：{', '.join(input_data.use_cases[:2])}")
            
            base_prompt = "。".join(prompt_parts)
            
        elif isinstance(input_data, ContentPiece):
            # 基于文案构建提示词
            base_prompt = f"内容主题：{input_data.text[:100]}..."
            
        else:
            base_prompt = str(input_data)
        
        # 组合完整提示词
        full_prompt = f"""{base_prompt}

风格要求：{style_desc}

图像要求：
- 高质量，专业摄影水准
- 适合电商展示
- 清晰的主体焦点
- 良好的构图和光线
"""
        
        return full_prompt
    
    async def _download_image(self, url: str, save_path: str):
        """下载图像到本地"""
        import aiohttp
        
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as response:
                if response.status == 200:
                    with open(save_path, 'wb') as f:
                        f.write(await response.read())
                    logger.info(f"Image downloaded to: {save_path}")
                else:
                    raise Exception(f"Failed to download image: {response.status}")
    
    async def edit_image(self, image: GeneratedImage, edit_type: str, 
                        **kwargs) -> GeneratedImage:
        """
        编辑已有图像
        
        Args:
            image: 原始图像
            edit_type: 编辑类型（background, upscale, style_transfer等）
            **kwargs: 编辑参数
            
        Returns:
            编辑后的图像
        """
        logger.info(f"Editing image {image.id} with type: {edit_type}")
        
        if edit_type == "background":
            # 背景替换/去除
            new_background = kwargs.get("background", "white")
            prompt = f"保持主体不变，将背景替换为{new_background}，专业产品摄影风格"
            
        elif edit_type == "upscale":
            # 图像放大
            prompt = "保持图像内容，提升分辨率和细节，高清增强"
            
        elif edit_type == "style_transfer":
            # 风格迁移
            target_style = kwargs.get("target_style", "artistic")
            prompt = f"将图像转换为{target_style}风格"
            
        else:
            prompt = kwargs.get("prompt", "优化图像质量")
        
        # 调用图像编辑 API
        try:
            result = await self.image_client.edit(
                image_path=image.local_path or image.url,
                prompt=prompt,
            )
            
            # 保存编辑后的图像
            edit_id = f"{image.id}-EDIT"
            local_path = os.path.join(self.output_dir, f"{edit_id}.png")
            
            if result.get("local_path"):
                import shutil
                shutil.copy(result["local_path"], local_path)
            
            return GeneratedImage(
                id=edit_id,
                url=result.get("url"),
                local_path=local_path,
                prompt=prompt,
                style=f"{image.style}-{edit_type}",
                product_id=image.product_id,
                content_id=image.content_id,
            )
            
        except Exception as e:
            logger.error(f"Image editing failed: {e}")
            raise
    
    async def generate_banner(self, product: Product, content_set: ContentSet,
                             **kwargs) -> GeneratedImage:
        """
        生成营销横幅
        
        Args:
            product: 商品对象
            content_set: 内容集合（包含文案）
            **kwargs: 额外参数
            
        Returns:
            横幅图像
        """
        headline = content_set.headline.text if content_set.headline else product.name
        slogan = content_set.slogans[0].text if content_set.slogans else ""
        
        prompt = f"""创建电商营销横幅：

商品：{product.name}
主标题：{headline}
标语：{slogan}
价格：{product.currency} {product.price}

设计要求：
- 专业电商横幅，16:9比例
- 突出商品和核心卖点
- 包含价格信息区域
- 现代简洁的设计风格
- 吸引眼球的配色
- 适合网站首页展示
"""
        
        return await self._generate_single_image(
            product, 
            style="product",
            size="banner",
            content_piece=content_set.headline
        )
