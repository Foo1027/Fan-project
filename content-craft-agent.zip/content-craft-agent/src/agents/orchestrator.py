"""
内容生产编排器
协调多个 Agent 完成完整的内容生产流程
"""

from typing import Dict, List, Optional, Any, Callable
import uuid
import asyncio
from datetime import datetime
from loguru import logger

from .base_agent import BaseAgent
from .product_analyzer import ProductAnalyzer
from .copywriter import CopywriterAgent
from .image_generator import ImageGeneratorAgent
from .ab_tester import ABTesterAgent
from ..models.product import Product
from ..models.content import ContentSet, ContentStyle
from ..models.ab_test import ABTest, ABTestResult


class ContentOrchestrator:
    """
    内容生产编排器
    
    负责协调多个 Agent，完成从商品分析到内容生成、
    图像生成、A/B测试的完整流程。
    
    支持的工作流：
    1. 简单模式：商品 → 文案 → 完成
    2. 完整模式：商品 → 文案 → 图像 → 完成
    3. 优化模式：商品 → 文案 → A/B测试 → 优化 → 完成
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        初始化编排器
        
        Args:
            config: 配置字典
        """
        self.config = config or {}
        
        # 初始化各个 Agent
        self.product_analyzer = ProductAnalyzer(config=self.config.get("analyzer"))
        self.copywriter = CopywriterAgent(config=self.config.get("copywriter"))
        self.image_generator = ImageGeneratorAgent(config=self.config.get("image"))
        self.ab_tester = ABTesterAgent(config=self.config.get("ab_test"))
        
        # 统计信息
        self.stats = {
            "total_products_processed": 0,
            "total_content_sets_generated": 0,
            "total_images_generated": 0,
            "total_ab_tests_created": 0,
            "start_time": datetime.now(),
        }
        
        # 回调函数
        self.progress_callbacks: List[Callable] = []
        
        logger.info("ContentOrchestrator initialized")
    
    async def process_product(self, product_input: Any, 
                             mode: str = "complete",
                             **kwargs) -> Dict[str, Any]:
        """
        处理单个商品，生成完整内容
        
        Args:
            product_input: 商品输入（文本、URL、字典等）
            mode: 处理模式
                - "simple": 仅生成文案
                - "complete": 文案 + 图像
                - "optimized": 文案 + 图像 + A/B测试
            **kwargs:
                - style: 文案风格
                - generate_variants: 是否生成变体
                - num_variants: 变体数量
        
        Returns:
            包含所有生成内容的字典
        """
        style = kwargs.get("style", ContentStyle.MARKETING)
        generate_variants = kwargs.get("generate_variants", False)
        
        logger.info(f"Processing product in {mode} mode with {style.value} style")
        
        result = {
            "product": None,
            "content_sets": [],
            "images": [],
            "ab_tests": [],
            "metadata": {
                "mode": mode,
                "style": style.value,
                "started_at": datetime.now().isoformat(),
            }
        }
        
        try:
            # Step 1: 分析商品
            self._notify_progress("analyzing", "正在分析商品信息...")
            product = await self.product_analyzer.run(product_input)
            result["product"] = product
            self.stats["total_products_processed"] += 1
            
            # Step 2: 生成文案
            self._notify_progress("copywriting", "正在生成文案...")
            content_set = await self.copywriter.run(product, style=style)
            result["content_sets"].append(content_set)
            self.stats["total_content_sets_generated"] += 1
            
            # Step 3: 生成图像（完整模式和优化模式）
            if mode in ["complete", "optimized"]:
                self._notify_progress("generating_images", "正在生成配图...")
                content_set = await self.image_generator.generate_for_content_set(
                    product, content_set
                )
                result["images"] = content_set.images
                self.stats["total_images_generated"] += len(content_set.images)
            
            # Step 4: A/B 测试（优化模式）
            if mode == "optimized":
                self._notify_progress("ab_testing", "正在创建 A/B 测试...")
                ab_test = await self.ab_tester.run(
                    content_set,
                    product=product,
                    num_variants=kwargs.get("num_variants", 1),
                )
                result["ab_tests"].append(ab_test)
                self.stats["total_ab_tests_created"] += 1
                
                # 启动测试
                await self.ab_tester.start_test(ab_test.id)
            
            # 生成变体（如果需要）
            if generate_variants and mode != "optimized":
                self._notify_progress("generating_variants", "正在生成风格变体...")
                variants = await self._generate_variants(product, content_set, kwargs)
                result["content_sets"].extend(variants)
            
            result["metadata"]["completed_at"] = datetime.now().isoformat()
            self._notify_progress("completed", "内容生成完成！")
            
            logger.success(f"Product processing completed: {product.name}")
            return result
            
        except Exception as e:
            logger.error(f"Product processing failed: {e}")
            result["metadata"]["error"] = str(e)
            raise
    
    async def process_batch(self, products: List[Any], 
                           mode: str = "complete",
                           max_concurrency: int = 3,
                           **kwargs) -> List[Dict[str, Any]]:
        """
        批量处理多个商品
        
        Args:
            products: 商品输入列表
            mode: 处理模式
            max_concurrency: 最大并发数
            **kwargs: 其他参数
        
        Returns:
            结果列表
        """
        logger.info(f"Batch processing {len(products)} products with max concurrency {max_concurrency}")
        
        semaphore = asyncio.Semaphore(max_concurrency)
        
        async def process_with_semaphore(product):
            async with semaphore:
                return await self.process_product(product, mode, **kwargs)
        
        # 并发处理
        tasks = [process_with_semaphore(p) for p in products]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # 统计结果
        successful = sum(1 for r in results if not isinstance(r, Exception))
        logger.success(f"Batch processing completed: {successful}/{len(products)} successful")
        
        return results
    
    async def _generate_variants(self, product: Product, base_content: ContentSet,
                                kwargs: Dict[str, Any]) -> List[ContentSet]:
        """生成内容变体"""
        num_variants = kwargs.get("num_variants", 2)
        variant_styles = [
            ContentStyle.STORY,
            ContentStyle.PROFESSIONAL,
            ContentStyle.FUN,
        ]
        
        variants = []
        for i in range(min(num_variants, len(variant_styles))):
            style = variant_styles[i]
            variant = await self.copywriter.generate_variant(base_content, style)
            
            # 也为变体生成图像
            variant = await self.image_generator.generate_for_content_set(product, variant)
            
            variants.append(variant)
            self.stats["total_content_sets_generated"] += 1
        
        return variants
    
    def _notify_progress(self, stage: str, message: str):
        """通知进度更新"""
        logger.info(f"[{stage}] {message}")
        for callback in self.progress_callbacks:
            try:
                callback(stage, message)
            except Exception as e:
                logger.warning(f"Progress callback failed: {e}")
    
    def on_progress(self, callback: Callable[[str, str], None]):
        """
        注册进度回调函数
        
        Args:
            callback: 回调函数，接收 (stage, message) 参数
        """
        self.progress_callbacks.append(callback)
    
    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        stats = self.stats.copy()
        stats["uptime_seconds"] = (datetime.now() - stats["start_time"]).total_seconds()
        
        # 添加各 Agent 的统计
        stats["agents"] = {
            "product_analyzer": self.product_analyzer.get_stats(),
            "copywriter": self.copywriter.get_stats(),
            "image_generator": self.image_generator.get_stats(),
            "ab_tester": self.ab_tester.get_stats(),
        }
        
        return stats
    
    async def get_ab_test_report(self, test_id: str) -> Optional[ABTestResult]:
        """
        获取 A/B 测试报告
        
        Args:
            test_id: 测试ID
            
        Returns:
            测试报告，如果测试不存在则返回 None
        """
        try:
            return await self.ab_tester.complete_test(test_id)
        except ValueError:
            return None
    
    async def update_ab_test_metrics(self, test_id: str, variant_id: str,
                                    impressions: int = 0, clicks: int = 0,
                                    conversions: int = 0):
        """
        更新 A/B 测试指标
        
        Args:
            test_id: 测试ID
            variant_id: 变体ID
            impressions: 曝光增量
            clicks: 点击增量
            conversions: 转化增量
        """
        await self.ab_tester.record_metrics(
            test_id, variant_id, impressions, clicks, conversions
        )
    
    def reset_stats(self):
        """重置统计信息"""
        self.stats = {
            "total_products_processed": 0,
            "total_content_sets_generated": 0,
            "total_images_generated": 0,
            "total_ab_tests_created": 0,
            "start_time": datetime.now(),
        }
        
        # 重置各 Agent 的统计
        self.product_analyzer.reset_stats()
        self.copywriter.reset_stats()
        self.image_generator.reset_stats()
        self.ab_tester.reset_stats()
        
        logger.info("All stats reset")
    
    async def generate_content_for_platform(self, product: Product, 
                                           platform: str,
                                           **kwargs) -> ContentSet:
        """
        为特定平台生成优化内容
        
        Args:
            product: 商品对象
            platform: 平台名称（weibo, xiaohongshu, douyin, taobao等）
            **kwargs: 额外参数
            
        Returns:
            优化后的内容集合
        """
        # 平台特定的配置
        platform_configs = {
            "xiaohongshu": {
                "style": ContentStyle.STORY,
                "image_size": "portrait",
                "image_count": 3,
            },
            "weibo": {
                "style": ContentStyle.MARKETING,
                "image_size": "square",
                "image_count": 1,
            },
            "douyin": {
                "style": ContentStyle.FUN,
                "image_size": "story",
                "image_count": 1,
            },
            "taobao": {
                "style": ContentStyle.MARKETING,
                "image_size": "square",
                "image_count": 5,
            },
        }
        
        config = platform_configs.get(platform, platform_configs["taobao"])
        
        # 生成内容
        content_set = await self.copywriter.run(
            product, 
            style=config["style"]
        )
        
        # 生成平台优化的图像
        images = await self.image_generator.process(
            product,
            style="product" if platform == "taobao" else "lifestyle",
            size=config["image_size"],
            count=config["image_count"],
        )
        content_set.images.extend(images)
        
        logger.success(f"Platform-optimized content generated for {platform}")
        return content_set
