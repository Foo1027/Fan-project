"""
文案生成 Agent
负责生成各种风格和类型的营销文案
"""

from typing import Dict, List, Optional, Any
import uuid
from datetime import datetime
from loguru import logger

from .base_agent import BaseAgent
from ..models.product import Product
from ..models.content import ContentPiece, ContentSet, ContentType, ContentStyle
from ..tools.llm_client import LLMClient


class CopywriterAgent(BaseAgent):
    """
    文案生成 Agent
    
    功能：
    1. 生成多风格文案（营销型、专业型、故事型等）
    2. 生成不同长度的内容（标题、描述、故事等）
    3. 生成社交媒体文案
    4. 支持 A/B 测试变体生成
    """
    
    # 风格提示词映射
    STYLE_PROMPTS = {
        ContentStyle.MARKETING: """营销型风格要求：
- 强调促销、限时优惠、紧迫感
- 使用行动号召性语言
- 突出性价比和优惠力度
- 语气热情、有感染力""",
        
        ContentStyle.PROFESSIONAL: """专业型风格要求：
- 强调技术参数和专业性能
- 使用行业术语和专业表达
- 突出产品优势和可靠性
- 语气严谨、权威""",
        
        ContentStyle.STORY: """故事型风格要求：
- 用场景化的故事引入
- 强调情感共鸣和体验
- 描述使用前后的变化
- 语气温暖、有代入感""",
        
        ContentStyle.MINIMAL: """简约型风格要求：
- 简洁有力，不堆砌形容词
- 突出核心卖点
- 留白感，高端调性
- 语气克制、优雅""",
        
        ContentStyle.FUN: """趣味型风格要求：
- 轻松幽默，有趣味性
- 使用网络流行语（适度）
- 制造惊喜感和好奇心
- 语气活泼、年轻化""",
        
        ContentStyle.LUXURY: """奢华型风格要求：
- 强调品质、工艺、独特性
- 使用高端词汇和修辞
- 营造尊贵感和稀缺性
- 语气优雅、有格调""",
    }
    
    def __init__(self, llm_client: Optional[LLMClient] = None, config: Optional[Dict[str, Any]] = None):
        super().__init__("CopywriterAgent", config)
        self.llm = llm_client or LLMClient()
    
    async def process(self, input_data: Product, **kwargs) -> ContentSet:
        """
        生成完整的内容集合
        
        Args:
            input_data: Product 对象
            **kwargs:
                - style: 主要风格（默认 MARKETING）
                - generate_variants: 是否生成 A/B 测试变体
                - num_variants: 变体数量
        
        Returns:
            ContentSet 对象
        """
        product = input_data
        style = kwargs.get("style", ContentStyle.MARKETING)
        generate_variants = kwargs.get("generate_variants", False)
        num_variants = kwargs.get("num_variants", 2)
        
        logger.info(f"Generating content for product: {product.name}, style: {style.value}")
        
        # 创建内容集合
        content_set = ContentSet(
            id=f"CS-{str(uuid.uuid4())[:8]}",
            product_id=product.id,
            name=f"{product.name} - {style.value}风格",
            primary_style=style,
        )
        
        # 生成核心文案
        content_set.headline = await self._generate_headline(product, style)
        content_set.subheadline = await self._generate_subheadline(product, style)
        content_set.description = await self._generate_description(product, style)
        content_set.story = await self._generate_story(product, style)
        
        # 生成标语
        content_set.slogans = await self._generate_slogans(product, style, count=3)
        
        # 生成社交媒体文案
        content_set.social_posts = await self._generate_social_posts(product, style, count=3)
        
        logger.success(f"Content generation completed for: {product.name}")
        return content_set
    
    async def generate_variant(self, content_set: ContentSet, variant_style: ContentStyle) -> ContentSet:
        """
        生成不同风格的变体版本（用于 A/B 测试）
        
        Args:
            content_set: 原始内容集合
            variant_style: 变体风格
            
        Returns:
            新的 ContentSet 变体
        """
        # 获取原始产品信息
        # 这里简化处理，实际应该从 content_set 反查 product
        
        variant = ContentSet(
            id=f"CS-VAR-{str(uuid.uuid4())[:8]}",
            product_id=content_set.product_id,
            name=f"{content_set.name} - {variant_style.value}变体",
            primary_style=variant_style,
            is_variant=True,
            parent_id=content_set.id,
            variant_name=f"{variant_style.value.upper()}变体",
        )
        
        # 重新生成所有内容
        # 注意：这里需要 product 对象，简化版代码
        # 实际实现中应该从 data store 获取 product
        
        return variant
    
    async def _generate_headline(self, product: Product, style: ContentStyle) -> ContentPiece:
        """生成主标题"""
        prompt = f"""为以下商品创作一个吸引人的主标题（10-20字）：

{product.to_prompt_text()}

{self.STYLE_PROMPTS[style]}

要求：
1. 突出核心卖点
2. 简洁有力，易记易传播
3. 符合指定风格
4. 只返回标题文本，不要其他内容
"""
        
        text = await self.llm.generate(prompt=prompt, temperature=0.7, max_tokens=100)
        text = text.strip().strip('"').strip("'")
        
        return ContentPiece(
            id=f"HEAD-{str(uuid.uuid4())[:8]}",
            type=ContentType.HEADLINE,
            style=style,
            text=text,
            product_id=product.id,
        )
    
    async def _generate_subheadline(self, product: Product, style: ContentStyle) -> ContentPiece:
        """生成副标题"""
        discount = product.get_discount_info()
        discount_text = f"\n促销信息：{discount}" if discount else ""
        
        prompt = f"""为以下商品创作一个副标题（15-30字）：

{product.to_prompt_text()}{discount_text}

{self.STYLE_PROMPTS[style]}

要求：
1. 补充主标题，提供更多卖点
2. 可以包含促销信息（如有）
3. 只返回副标题文本
"""
        
        text = await self.llm.generate(prompt=prompt, temperature=0.6, max_tokens=150)
        text = text.strip().strip('"').strip("'")
        
        return ContentPiece(
            id=f"SUB-{str(uuid.uuid4())[:8]}",
            type=ContentType.SUBTITLE,
            style=style,
            text=text,
            product_id=product.id,
        )
    
    async def _generate_description(self, product: Product, style: ContentStyle) -> ContentPiece:
        """生成商品描述"""
        prompt = f"""为以下商品创作一段商品描述（100-200字）：

{product.to_prompt_text()}

{self.STYLE_PROMPTS[style]}

要求：
1. 结构清晰，分2-3个段落
2. 突出核心功能和优势
3. 包含使用场景
4. 结尾有行动号召
"""
        
        text = await self.llm.generate(prompt=prompt, temperature=0.6, max_tokens=500)
        text = text.strip()
        
        return ContentPiece(
            id=f"DESC-{str(uuid.uuid4())[:8]}",
            type=ContentType.DESCRIPTION,
            style=style,
            text=text,
            product_id=product.id,
        )
    
    async def _generate_story(self, product: Product, style: ContentStyle) -> ContentPiece:
        """生成品牌故事/使用场景故事"""
        if style == ContentStyle.PROFESSIONAL:
            # 专业型风格改为技术详解
            prompt = f"""为以下商品创作一段技术详解（150-250字）：

{product.to_prompt_text()}

要求：
1. 深入介绍核心技术原理
2. 对比行业标准和竞品优势
3. 说明技术带来的实际价值
4. 专业但易懂
"""
        else:
            prompt = f"""为以下商品创作一个使用场景故事（150-250字）：

{product.to_prompt_text()}

{self.STYLE_PROMPTS[style]}

要求：
1. 设定一个具体的用户角色和场景
2. 描述使用前后的对比
3. 突出情感体验和满意度
4. 自然融入产品卖点
"""
        
        text = await self.llm.generate(prompt=prompt, temperature=0.7, max_tokens=600)
        text = text.strip()
        
        return ContentPiece(
            id=f"STORY-{str(uuid.uuid4())[:8]}",
            type=ContentType.STORY,
            style=style,
            text=text,
            product_id=product.id,
        )
    
    async def _generate_slogans(self, product: Product, style: ContentStyle, count: int = 3) -> List[ContentPiece]:
        """生成多条标语"""
        prompt = f"""为以下商品创作{count}条不同角度的标语（每条8-15字）：

{product.to_prompt_text()}

{self.STYLE_PROMPTS[style]}

要求：
1. 每条标语突出不同的卖点
2. 朗朗上口，易记易传播
3. 每条标语单独一行
4. 只返回标语文本，不要编号
"""
        
        text = await self.llm.generate(prompt=prompt, temperature=0.8, max_tokens=300)
        lines = [line.strip().strip('"').strip("'") for line in text.strip().split('\n') if line.strip()]
        
        slogans = []
        for i, line in enumerate(lines[:count]):
            slogans.append(ContentPiece(
                id=f"SLOGAN-{str(uuid.uuid4())[:8]}",
                type=ContentType.SLOGAN,
                style=style,
                text=line,
                product_id=product.id,
            ))
        
        return slogans
    
    async def _generate_social_posts(self, product: Product, style: ContentStyle, count: int = 3) -> List[ContentPiece]:
        """生成社交媒体文案"""
        prompt = f"""为以下商品创作{count}条社交媒体推广文案（每条50-100字）：

{product.to_prompt_text()}

{self.STYLE_PROMPTS[style]}

要求：
1. 适合发布在微博、小红书、朋友圈等平台
2. 可以包含 emoji（适当使用）
3. 包含话题标签建议
4. 每条文案之间用 --- 分隔
5. 语气轻松、互动性强
"""
        
        text = await self.llm.generate(prompt=prompt, temperature=0.8, max_tokens=800)
        posts = text.split('---')
        
        social_posts = []
        for i, post in enumerate(posts[:count]):
            post = post.strip()
            if post:
                social_posts.append(ContentPiece(
                    id=f"SOCIAL-{str(uuid.uuid4())[:8]}",
                    type=ContentType.SOCIAL,
                    style=style,
                    text=post,
                    product_id=product.id,
                ))
        
        return social_posts
    
    async def optimize_for_keyword(self, content: ContentPiece, keyword: str) -> ContentPiece:
        """
        优化文案以包含特定关键词（用于 SEO）
        
        Args:
            content: 原始文案
            keyword: 目标关键词
            
        Returns:
            优化后的文案
        """
        prompt = f"""请优化以下文案，自然地融入关键词"{keyword}"：

原文案：
{content.text}

要求：
1. 保持原有风格和语气
2. 关键词出现1-2次，自然融入
3. 不改变核心意思
4. 只返回优化后的文案
"""
        
        optimized_text = await self.llm.generate(prompt=prompt, temperature=0.5, max_tokens=500)
        
        return ContentPiece(
            id=f"{content.id}-OPT",
            type=content.type,
            style=content.style,
            text=optimized_text.strip(),
            product_id=content.product_id,
            version=content.version + 1,
        )