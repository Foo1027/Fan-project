"""
基础 Agent 类
所有 Agent 的基类，定义通用接口和功能
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional
from datetime import datetime
import uuid
from loguru import logger


class BaseAgent(ABC):
    """
    基础 Agent 类
    
    所有具体 Agent 都需要继承此类，实现 process 方法
    """
    
    def __init__(self, name: str, config: Optional[Dict[str, Any]] = None):
        """
        初始化 Agent
        
        Args:
            name: Agent 名称
            config: 配置字典
        """
        self.name = name
        self.config = config or {}
        self.id = str(uuid.uuid4())
        self.created_at = datetime.now()
        self.last_run_at: Optional[datetime] = None
        self.run_count = 0
        
        logger.info(f"Agent '{name}' initialized with ID: {self.id}")
    
    @abstractmethod
    async def process(self, input_data: Any, **kwargs) -> Any:
        """
        处理输入数据的核心方法
        
        Args:
            input_data: 输入数据
            **kwargs: 额外参数
            
        Returns:
            处理结果
        """
        pass
    
    async def run(self, input_data: Any, **kwargs) -> Any:
        """
        运行 Agent（带日志和统计）
        
        Args:
            input_data: 输入数据
            **kwargs: 额外参数
            
        Returns:
            处理结果
        """
        logger.info(f"Agent '{self.name}' starting run #{self.run_count + 1}")
        
        try:
            result = await self.process(input_data, **kwargs)
            
            self.last_run_at = datetime.now()
            self.run_count += 1
            
            logger.success(f"Agent '{self.name}' completed run #{self.run_count}")
            return result
            
        except Exception as e:
            logger.error(f"Agent '{self.name}' failed: {str(e)}")
            raise
    
    def get_stats(self) -> Dict[str, Any]:
        """获取 Agent 统计信息"""
        return {
            "agent_id": self.id,
            "name": self.name,
            "created_at": self.created_at.isoformat(),
            "last_run_at": self.last_run_at.isoformat() if self.last_run_at else None,
            "run_count": self.run_count,
        }
    
    def update_config(self, new_config: Dict[str, Any]):
        """更新配置"""
        self.config.update(new_config)
        logger.info(f"Agent '{self.name}' config updated")
    
    def reset_stats(self):
        """重置统计信息"""
        self.run_count = 0
        self.last_run_at = None
        logger.info(f"Agent '{self.name}' stats reset")
