"""
A/B 测试 Agent
负责创建、运行和分析 A/B 测试
"""

from typing import Dict, List, Optional, Any
import uuid
from datetime import datetime
from loguru import logger

from .base_agent import BaseAgent
from ..models.product import Product
from ..models.content import ContentSet, ContentStyle
from ..models.ab_test import ABTest, ABTestVariant, ABTestResult, TestMetric, TestStatus
from ..tools.llm_client import LLMClient


class ABTesterAgent(BaseAgent):
    """
    A/B 测试 Agent
    
    功能：
    1. 创建 A/B 测试计划
    2. 生成测试变体
    3. 监控测试进度
    4. 分析测试结果
    5. 提供优化建议
    """
    
    def __init__(self, llm_client: Optional[LLMClient] = None, config: Optional[Dict[str, Any]] = None):
        super().__init__("ABTesterAgent", config)
        self.llm = llm_client or LLMClient()
        self.active_tests: Dict[str, ABTest] = {}
    
    async def process(self, input_data: ContentSet, **kwargs) -> ABTest:
        """
        创建并启动 A/B 测试
        
        Args:
            input_data: 基准内容集合（对照组）
            **kwargs:
                - product: 商品对象
                - num_variants: 变体数量（默认1个B版）
                - test_metric: 测试指标（默认CTR）
                - duration_days: 测试天数（默认7天）
                - traffic_split: 流量分配（默认50/50）
        
        Returns:
            ABTest 对象
        """
        content_set = input_data
        product = kwargs.get("product")
        num_variants = kwargs.get("num_variants", 1)
        test_metric = kwargs.get("test_metric", TestMetric.CTR)
        duration_days = kwargs.get("duration_days", 7)
        traffic_split = kwargs.get("traffic_split", [50, 50])
        
        logger.info(f"Creating A/B test for content set: {content_set.name}")
        
        # 创建测试
        test = await self._create_test(
            content_set=content_set,
            product=product,
            num_variants=num_variants,
            test_metric=test_metric,
            duration_days=duration_days,
            traffic_split=traffic_split,
        )
        
        # 保存到活跃测试列表
        self.active_tests[test.id] = test
        
        logger.success(f"A/B test created: {test.id}")
        return test
    
    async def _create_test(self, content_set: ContentSet, product: Optional[Product],
                          num_variants: int, test_metric: TestMetric,
                          duration_days: int, traffic_split: List[int]) -> ABTest:
        """创建测试对象"""
        
        test_id = f"AB-{str(uuid.uuid4())[:8]}"
        
        # 创建对照组变体
        control = ABTestVariant(
            id=f"VAR-A-{str(uuid.uuid4())[:6]}",
            name="A版（对照组）",
            content_set_id=content_set.id,
            traffic_percentage=traffic_split[0] if len(traffic_split) > 0 else 50,
        )
        
        # 生成实验组变体
        treatment_variants = []
        for i in range(num_variants):
            variant_name = chr(66 + i)  # B, C, D...
            
            # 生成不同风格的内容变体
            variant_style = self._get_variant_style(content_set.primary_style, i)
            variant_content = await self._generate_variant_content(
                content_set, variant_style, product
            )
            
            variant = ABTestVariant(
                id=f"VAR-{variant_name}-{str(uuid.uuid4())[:6]}",
                name=f"{variant_name}版（{variant_style.value}风格）",
                content_set_id=variant_content.id,
                traffic_percentage=traffic_split[i + 1] if len(traffic_split) > i + 1 else 50,
            )
            treatment_variants.append(variant)
        
        # 创建测试对象
        test = ABTest(
            id=test_id,
            name=f"{content_set.name} A/B测试",
            description=f"测试不同文案风格的效果，主要指标：{test_metric.value}",
            product_id=product.id if product else content_set.product_id,
            control_variant=control,
            treatment_variants=treatment_variants,
            primary_metric=test_metric,
            duration_days=duration_days,
        )
        
        return test
    
    def _get_variant_style(self, base_style: ContentStyle, index: int) -> ContentStyle:
        """根据基准风格生成变体风格"""
        style_cycle = [
            ContentStyle.MARKETING,
            ContentStyle.STORY,
            ContentStyle.PROFESSIONAL,
            ContentStyle.FUN,
            ContentStyle.MINIMAL,
        ]
        
        # 排除基准风格
        available_styles = [s for s in style_cycle if s != base_style]
        
        if index < len(available_styles):
            return available_styles[index]
        else:
            return available_styles[index % len(available_styles)]
    
    async def _generate_variant_content(self, base_content: ContentSet, 
                                       style: ContentStyle,
                                       product: Optional[Product]) -> ContentSet:
        """生成内容变体"""
        # 这里简化处理，实际应该调用 CopywriterAgent 重新生成
        # 为演示目的，创建一个新的 ContentSet 引用
        
        from ..agents.copywriter import CopywriterAgent
        
        if product:
            copywriter = CopywriterAgent()
            variant_set = await copywriter.process(product, style=style)
            variant_set.is_variant = True
            variant_set.parent_id = base_content.id
            variant_set.variant_name = f"{style.value.upper()}变体"
            return variant_set
        else:
            # 如果没有 product，复制并修改基准内容
            variant_set = ContentSet(
                id=f"CS-VAR-{str(uuid.uuid4())[:8]}",
                product_id=base_content.product_id,
                name=f"{base_content.name} - {style.value}变体",
                primary_style=style,
                is_variant=True,
                parent_id=base_content.id,
                variant_name=f"{style.value.upper()}变体",
            )
            return variant_set
    
    async def start_test(self, test_id: str) -> ABTest:
        """启动测试"""
        if test_id not in self.active_tests:
            raise ValueError(f"Test not found: {test_id}")
        
        test = self.active_tests[test_id]
        test.start()
        
        logger.info(f"A/B test started: {test_id}")
        return test
    
    async def record_metrics(self, test_id: str, variant_id: str,
                            impressions: int = 0, clicks: int = 0,
                            conversions: int = 0, revenue: float = 0.0):
        """
        记录测试指标
        
        Args:
            test_id: 测试ID
            variant_id: 变体ID
            impressions: 新增曝光
            clicks: 新增点击
            conversions: 新增转化
            revenue: 新增收入
        """
        if test_id not in self.active_tests:
            raise ValueError(f"Test not found: {test_id}")
        
        test = self.active_tests[test_id]
        test.update_metrics(variant_id, impressions, clicks, conversions, revenue)
        
        logger.debug(f"Metrics recorded for test {test_id}, variant {variant_id}")
        
        # 检查是否应该提前停止
        if test.status == TestStatus.RUNNING and test.should_stop_early():
            logger.info(f"Test {test_id} reached statistical significance, can be stopped early")
    
    async def get_test_status(self, test_id: str) -> Dict[str, Any]:
        """获取测试状态"""
        if test_id not in self.active_tests:
            raise ValueError(f"Test not found: {test_id}")
        
        test = self.active_tests[test_id]
        
        # 计算当前指标
        test.control_variant.calculate_metrics()
        for variant in test.treatment_variants:
            variant.calculate_metrics()
        
        return {
            "test_id": test.id,
            "name": test.name,
            "status": test.status.value,
            "primary_metric": test.primary_metric.value,
            "control": {
                "name": test.control_variant.name,
                "impressions": test.control_variant.impressions,
                "clicks": test.control_variant.clicks,
                "ctr": test.control_variant.ctr,
            },
            "treatments": [
                {
                    "name": v.name,
                    "impressions": v.impressions,
                    "clicks": v.clicks,
                    "ctr": v.ctr,
                    "lift": self._calculate_lift(test.control_variant, v),
                }
                for v in test.treatment_variants
            ],
            "days_running": (datetime.now() - test.start_time).days if test.start_time else 0,
            "can_stop_early": test.should_stop_early() if test.status == TestStatus.RUNNING else False,
        }
    
    def _calculate_lift(self, control: ABTestVariant, treatment: ABTestVariant) -> Optional[float]:
        """计算相对提升"""
        if control.ctr and treatment.ctr and control.ctr > 0:
            return (treatment.ctr - control.ctr) / control.ctr
        return None
    
    async def complete_test(self, test_id: str, 
                           winner_id: Optional[str] = None) -> ABTestResult:
        """
        完成测试并生成报告
        
        Args:
            test_id: 测试ID
            winner_id: 指定获胜变体ID（可选，不指定则自动选择）
        
        Returns:
            ABTestResult 报告
        """
        if test_id not in self.active_tests:
            raise ValueError(f"Test not found: {test_id}")
        
        test = self.active_tests[test_id]
        
        # 如果没有指定获胜者，自动选择
        if winner_id is None:
            best = test.get_best_variant()
            if best:
                winner_id = best.id
        
        # 完成测试
        test.complete(winner_id)
        
        # 生成报告
        result = ABTestResult.from_test(test)
        
        logger.success(f"A/B test completed: {test_id}, winner: {result.winner_variant}")
        return result
    
    async def generate_optimization_suggestions(self, test: ABTest) -> List[str]:
        """
        基于测试结果生成优化建议
        
        Args:
            test: 完成的测试
            
        Returns:
            建议列表
        """
        if test.status != TestStatus.COMPLETED:
            raise ValueError("Test must be completed before generating suggestions")
        
        # 构建提示词
        prompt = self._build_suggestion_prompt(test)
        
        try:
            response = await self.llm.generate(
                prompt=prompt,
                temperature=0.7,
                max_tokens=1000,
            )
            
            # 解析建议
            suggestions = [s.strip() for s in response.strip().split('\n') if s.strip()]
            return suggestions[:5]  # 最多返回5条
            
        except Exception as e:
            logger.error(f"Failed to generate suggestions: {e}")
            return ["基于测试结果继续优化文案内容"]
    
    def _build_suggestion_prompt(self, test: ABTest) -> str:
        """构建建议生成提示词"""
        
        control = test.control_variant
        control.calculate_metrics()
        
        lines = [
            f"基于以下 A/B 测试结果，提供5条具体的优化建议：",
            f"",
            f"测试名称：{test.name}",
            f"主要指标：{test.primary_metric.value}",
            f"",
            f"对照组（{control.name}）：",
            f"  - 曝光：{control.impressions}",
            f"  - 点击：{control.clicks}",
            f"  - CTR：{control.ctr:.2%}" if control.ctr else "  - CTR：N/A",
            f"",
            f"实验组：",
        ]
        
        for variant in test.treatment_variants:
            variant.calculate_metrics()
            lines.append(f"  {variant.name}:")
            lines.append(f"    - 曝光：{variant.impressions}")
            lines.append(f"    - 点击：{variant.clicks}")
            lines.append(f"    - CTR：{variant.ctr:.2%}" if variant.ctr else "    - CTR：N/A")
            
            if control.ctr and variant.ctr:
                lift = (variant.ctr - control.ctr) / control.ctr
                lines.append(f"    - 相对提升：{lift:+.1%}")
        
        if test.winner_variant_id:
            winner = test.get_variant_by_id(test.winner_variant_id)
            if winner:
                lines.append(f"")
                lines.append(f"获胜变体：{winner.name}")
        
        lines.append(f"")
        lines.append(f"请提供5条具体的优化建议，每条建议一行，格式如下：")
        lines.append(f"1. 建议内容...")
        lines.append(f"2. 建议内容...")
        
        return "\n".join(lines)
    
    def get_all_active_tests(self) -> List[ABTest]:
        """获取所有活跃测试"""
        return [test for test in self.active_tests.values() 
                if test.status == TestStatus.RUNNING]
    
    async def pause_test(self, test_id: str) -> ABTest:
        """暂停测试"""
        if test_id not in self.active_tests:
            raise ValueError(f"Test not found: {test_id}")
        
        test = self.active_tests[test_id]
        test.pause()
        
        logger.info(f"A/B test paused: {test_id}")
        return test
    
    async def resume_test(self, test_id: str) -> ABTest:
        """恢复测试"""
        if test_id not in self.active_tests:
            raise ValueError(f"Test not found: {test_id}")
        
        test = self.active_tests[test_id]
        test.status = TestStatus.RUNNING
        
        logger.info(f"A/B test resumed: {test_id}")
        return test