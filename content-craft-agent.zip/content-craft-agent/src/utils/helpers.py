"""
工具函数
"""

import re
import uuid
from typing import Optional


def generate_id(prefix: str = "") -> str:
    """
    生成唯一ID
    
    Args:
        prefix: ID前缀
        
    Returns:
        唯一ID字符串
    """
    unique_id = str(uuid.uuid4())[:8]
    if prefix:
        return f"{prefix}-{unique_id}"
    return unique_id


def sanitize_filename(filename: str) -> str:
    """
    清理文件名，移除非法字符
    
    Args:
        filename: 原始文件名
        
    Returns:
        清理后的文件名
    """
    # 移除非法字符
    sanitized = re.sub(r'[\\/*?:"<>|]', "", filename)
    # 限制长度
    if len(sanitized) > 100:
        sanitized = sanitized[:100]
    return sanitized.strip()


def format_price(price: float, currency: str = "CNY") -> str:
    """
    格式化价格显示
    
    Args:
        price: 价格数值
        currency: 货币代码
        
    Returns:
        格式化后的价格字符串
    """
    currency_symbols = {
        "CNY": "¥",
        "USD": "$",
        "EUR": "€",
        "GBP": "£",
        "JPY": "¥",
    }
    
    symbol = currency_symbols.get(currency, currency)
    return f"{symbol}{price:,.2f}"


def truncate_text(text: str, max_length: int, suffix: str = "...") -> str:
    """
    截断文本到指定长度
    
    Args:
        text: 原始文本
        max_length: 最大长度
        suffix: 截断后缀
        
    Returns:
        截断后的文本
    """
    if len(text) <= max_length:
        return text
    return text[:max_length - len(suffix)] + suffix


def count_tokens_approx(text: str) -> int:
    """
    估算文本的 token 数量（粗略估计）
    
    Args:
        text: 文本内容
        
    Returns:
        估算的 token 数
    """
    # 粗略估计：英文约 1 token/4 字符，中文约 1 token/1 字符
    # 这里使用一个简单的混合估算
    chinese_chars = len(re.findall(r'[\u4e00-\u9fff]', text))
    other_chars = len(text) - chinese_chars
    
    return chinese_chars + (other_chars // 4)


def extract_keywords(text: str, max_keywords: int = 5) -> list:
    """
    从文本中提取关键词（简单实现）
    
    Args:
        text: 文本内容
        max_keywords: 最大关键词数量
        
    Returns:
        关键词列表
    """
    # 简单的关键词提取：取最长的词
    words = re.findall(r'\b\w{2,}\b', text)
    word_freq = {}
    
    for word in words:
        word_lower = word.lower()
        if word_lower not in word_freq:
            word_freq[word_lower] = 0
        word_freq[word_lower] += 1
    
    # 按频率排序
    sorted_words = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)
    
    return [word for word, freq in sorted_words[:max_keywords]]


def validate_url(url: str) -> bool:
    """
    验证 URL 格式
    
    Args:
        url: URL 字符串
        
    Returns:
        是否有效
    """
    pattern = re.compile(
        r'^https?://'  # http:// 或 https://
        r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+[A-Z]{2,6}\.?|'  # 域名
        r'localhost|'  # localhost
        r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'  # IP
        r'(?::\d+)?'  # 端口
        r'(?:/?|[/?]\S+)$', re.IGNORECASE)
    
    return bool(pattern.match(url))


def calculate_discount(original_price: float, current_price: float) -> Optional[int]:
    """
    计算折扣百分比
    
    Args:
        original_price: 原价
        current_price: 现价
        
    Returns:
        折扣百分比，如果没有折扣则返回 None
    """
    if original_price <= 0 or current_price >= original_price:
        return None
    
    discount = (1 - current_price / original_price) * 100
    return int(discount)


def merge_dicts(base: dict, override: dict) -> dict:
    """
    递归合并两个字典
    
    Args:
        base: 基础字典
        override: 覆盖字典
        
    Returns:
        合并后的字典
    """
    result = base.copy()
    
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = merge_dicts(result[key], value)
        else:
            result[key] = value
    
    return result


def safe_json_loads(text: str, default=None):
    """
    安全地解析 JSON
    
    Args:
        text: JSON 字符串
        default: 解析失败时的默认值
        
    Returns:
        解析结果或默认值
    """
    import json
    
    try:
        return json.loads(text)
    except (json.JSONDecodeError, TypeError):
        return default if default is not None else {}


def chunk_list(lst: list, chunk_size: int):
    """
    将列表分块
    
    Args:
        lst: 列表
        chunk_size: 每块大小
        
    Yields:
        块
    """
    for i in range(0, len(lst), chunk_size):
        yield lst[i:i + chunk_size]