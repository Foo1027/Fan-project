"""
配置管理
"""

import os
from typing import Optional
from pydantic_settings import BaseSettings
from pydantic import Field


class Settings(BaseSettings):
    """
    应用配置类
    
    从环境变量读取配置
    """
    
    # 应用设置
    app_name: str = Field(default="ContentCraft Agent", description="应用名称")
    debug: bool = Field(default=False, description="调试模式")
    log_level: str = Field(default="INFO", description="日志级别")
    
    # LLM API 配置
    openai_api_key: Optional[str] = Field(default=None, description="OpenAI API Key")
    openai_base_url: str = Field(default="https://api.openai.com/v1", description="OpenAI API 基础URL")
    
    deepseek_api_key: Optional[str] = Field(default=None, description="DeepSeek API Key")
    deepseek_base_url: str = Field(default="https://api.deepseek.com/v1", description="DeepSeek API 基础URL")
    
    # 默认模型
    default_llm_model: str = Field(default="gpt-4-turbo-preview", description="默认LLM模型")
    default_image_model: str = Field(default="dall-e-3", description="默认图像生成模型")
    
    # 图像 API 配置
    dalle_api_key: Optional[str] = Field(default=None, description="DALL-E API Key")
    
    # 生成参数
    max_tokens_per_request: int = Field(default=4000, description="每次请求最大token数")
    temperature: float = Field(default=0.7, description="生成温度")
    
    # 存储配置
    data_storage_dir: str = Field(default="./data", description="数据存储目录")
    image_output_dir: str = Field(default="./output/images", description="图像输出目录")
    
    # 可选：Redis 配置
    redis_url: Optional[str] = Field(default=None, description="Redis URL")
    
    # 可选：数据库配置
    database_url: Optional[str] = Field(default=None, description="数据库URL")
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False


# 全局配置实例
_settings: Optional[Settings] = None


def get_settings() -> Settings:
    """获取配置实例（单例模式）"""
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings


def reload_settings() -> Settings:
    """重新加载配置"""
    global _settings
    _settings = Settings()
    return _settings