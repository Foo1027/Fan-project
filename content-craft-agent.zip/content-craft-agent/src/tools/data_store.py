"""
数据存储
用于持久化商品、内容和测试数据
"""

import json
import os
from typing import Dict, List, Optional, Any
from datetime import datetime
from pathlib import Path
from loguru import logger


class DataStore:
    """
    数据存储类
    
    支持：
    - JSON 文件存储（默认）
    - 可选：数据库存储
    """
    
    def __init__(self, storage_dir: str = "./data"):
        """
        初始化数据存储
        
        Args:
            storage_dir: 数据存储目录
        """
        self.storage_dir = Path(storage_dir)
        self.storage_dir.mkdir(parents=True, exist_ok=True)
        
        # 子目录
        self.products_dir = self.storage_dir / "products"
        self.content_dir = self.storage_dir / "content"
        self.tests_dir = self.storage_dir / "tests"
        
        for dir_path in [self.products_dir, self.content_dir, self.tests_dir]:
            dir_path.mkdir(exist_ok=True)
        
        logger.info(f"DataStore initialized at: {self.storage_dir}")
    
    def save_product(self, product: Any) -> str:
        """
        保存商品
        
        Args:
            product: Product 对象或字典
            
        Returns:
            文件路径
        """
        product_id = getattr(product, 'id', product.get('id', 'unknown'))
        file_path = self.products_dir / f"{product_id}.json"
        
        # 转换为字典
        if hasattr(product, 'dict'):
            data = product.dict()
        elif hasattr(product, 'model_dump'):
            data = product.model_dump()
        else:
            data = dict(product)
        
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2, default=str)
        
        logger.debug(f"Product saved: {file_path}")
        return str(file_path)
    
    def load_product(self, product_id: str) -> Optional[Dict[str, Any]]:
        """
        加载商品
        
        Args:
            product_id: 商品ID
            
        Returns:
            商品数据字典，不存在则返回 None
        """
        file_path = self.products_dir / f"{product_id}.json"
        
        if not file_path.exists():
            return None
        
        with open(file_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def save_content_set(self, content_set: Any) -> str:
        """
        保存内容集合
        
        Args:
            content_set: ContentSet 对象
            
        Returns:
            文件路径
        """
        content_id = getattr(content_set, 'id', content_set.get('id', 'unknown'))
        file_path = self.content_dir / f"{content_id}.json"
        
        # 转换为字典
        if hasattr(content_set, 'dict'):
            data = content_set.dict()
        elif hasattr(content_set, 'model_dump'):
            data = content_set.model_dump()
        else:
            data = dict(content_set)
        
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2, default=str)
        
        logger.debug(f"Content set saved: {file_path}")
        return str(file_path)
    
    def load_content_set(self, content_id: str) -> Optional[Dict[str, Any]]:
        """
        加载内容集合
        
        Args:
            content_id: 内容ID
            
        Returns:
            内容数据字典，不存在则返回 None
        """
        file_path = self.content_dir / f"{content_id}.json"
        
        if not file_path.exists():
            return None
        
        with open(file_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def save_ab_test(self, test: Any) -> str:
        """
        保存 A/B 测试
        
        Args:
            test: ABTest 对象
            
        Returns:
            文件路径
        """
        test_id = getattr(test, 'id', test.get('id', 'unknown'))
        file_path = self.tests_dir / f"{test_id}.json"
        
        # 转换为字典
        if hasattr(test, 'dict'):
            data = test.dict()
        elif hasattr(test, 'model_dump'):
            data = test.model_dump()
        else:
            data = dict(test)
        
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2, default=str)
        
        logger.debug(f"A/B test saved: {file_path}")
        return str(file_path)
    
    def load_ab_test(self, test_id: str) -> Optional[Dict[str, Any]]:
        """
        加载 A/B 测试
        
        Args:
            test_id: 测试ID
            
        Returns:
            测试数据字典，不存在则返回 None
        """
        file_path = self.tests_dir / f"{test_id}.json"
        
        if not file_path.exists():
            return None
        
        with open(file_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def list_products(self) -> List[str]:
        """列出所有商品ID"""
        return [f.stem for f in self.products_dir.glob("*.json")]
    
    def list_content_sets(self, product_id: Optional[str] = None) -> List[str]:
        """
        列出内容集合ID
        
        Args:
            product_id: 可选，筛选特定商品的内容
        """
        content_ids = []
        for f in self.content_dir.glob("*.json"):
            if product_id:
                data = self.load_content_set(f.stem)
                if data and data.get('product_id') == product_id:
                    content_ids.append(f.stem)
            else:
                content_ids.append(f.stem)
        return content_ids
    
    def list_ab_tests(self, product_id: Optional[str] = None) -> List[str]:
        """
        列出 A/B 测试ID
        
        Args:
            product_id: 可选，筛选特定商品的测试
        """
        test_ids = []
        for f in self.tests_dir.glob("*.json"):
            if product_id:
                data = self.load_ab_test(f.stem)
                if data and data.get('product_id') == product_id:
                    test_ids.append(f.stem)
            else:
                test_ids.append(f.stem)
        return test_ids
    
    def delete_product(self, product_id: str) -> bool:
        """
        删除商品
        
        Args:
            product_id: 商品ID
            
        Returns:
            是否成功删除
        """
        file_path = self.products_dir / f"{product_id}.json"
        if file_path.exists():
            file_path.unlink()
            logger.debug(f"Product deleted: {product_id}")
            return True
        return False
    
    def delete_content_set(self, content_id: str) -> bool:
        """
        删除内容集合
        
        Args:
            content_id: 内容ID
            
        Returns:
            是否成功删除
        """
        file_path = self.content_dir / f"{content_id}.json"
        if file_path.exists():
            file_path.unlink()
            logger.debug(f"Content set deleted: {content_id}")
            return True
        return False
    
    def delete_ab_test(self, test_id: str) -> bool:
        """
        删除 A/B 测试
        
        Args:
            test_id: 测试ID
            
        Returns:
            是否成功删除
        """
        file_path = self.tests_dir / f"{test_id}.json"
        if file_path.exists():
            file_path.unlink()
            logger.debug(f"A/B test deleted: {test_id}")
            return True
        return False
    
    def export_all(self, export_dir: str) -> str:
        """
        导出所有数据
        
        Args:
            export_dir: 导出目录
            
        Returns:
            导出目录路径
        """
        export_path = Path(export_dir)
        export_path.mkdir(parents=True, exist_ok=True)
        
        # 导出商品
        products_export = export_path / "products.json"
        products_data = []
        for product_id in self.list_products():
            data = self.load_product(product_id)
            if data:
                products_data.append(data)
        
        with open(products_export, 'w', encoding='utf-8') as f:
            json.dump(products_data, f, ensure_ascii=False, indent=2, default=str)
        
        # 导出内容
        content_export = export_path / "content_sets.json"
        content_data = []
        for content_id in self.list_content_sets():
            data = self.load_content_set(content_id)
            if data:
                content_data.append(data)
        
        with open(content_export, 'w', encoding='utf-8') as f:
            json.dump(content_data, f, ensure_ascii=False, indent=2, default=str)
        
        # 导出测试
        tests_export = export_path / "ab_tests.json"
        tests_data = []
        for test_id in self.list_ab_tests():
            data = self.load_ab_test(test_id)
            if data:
                tests_data.append(data)
        
        with open(tests_export, 'w', encoding='utf-8') as f:
            json.dump(tests_data, f, ensure_ascii=False, indent=2, default=str)
        
        logger.info(f"All data exported to: {export_path}")
        return str(export_path)
    
    def get_stats(self) -> Dict[str, int]:
        """获取存储统计"""
        return {
            "products_count": len(self.list_products()),
            "content_sets_count": len(self.list_content_sets()),
            "ab_tests_count": len(self.list_ab_tests()),
        }