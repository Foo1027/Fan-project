"""
LLM 客户端
封装对各种大语言模型 API 的调用
"""

import os
from typing import Dict, List, Optional, Any, AsyncGenerator
import httpx
from loguru import logger


class LLMClient:
    """
    大语言模型客户端
    
    支持：
    - OpenAI API
    - DeepSeek API
    - 其他兼容 OpenAI 格式的 API
    """
    
    def __init__(self, 
                 api_key: Optional[str] = None,
                 base_url: Optional[str] = None,
                 model: Optional[str] = None):
        """
        初始化 LLM 客户端
        
        Args:
            api_key: API Key，默认从环境变量读取
            base_url: API 基础 URL
            model: 默认模型名称
        """
        # 优先使用传入的参数，其次环境变量
        self.api_key = api_key or os.getenv("OPENAI_API_KEY") or os.getenv("DEEPSEEK_API_KEY")
        self.base_url = base_url or os.getenv("OPENAI_BASE_URL") or os.getenv("DEEPSEEK_BASE_URL", "https://api.openai.com/v1")
        self.model = model or os.getenv("DEFAULT_LLM_MODEL", "gpt-4-turbo-preview")
        
        if not self.api_key:
            logger.warning("No API key provided. LLM calls will fail.")
        
        # 初始化 HTTP 客户端
        self.client = httpx.AsyncClient(
            base_url=self.base_url,
            headers={"Authorization": f"Bearer {self.api_key}"},
            timeout=60.0,
        )
        
        logger.info(f"LLMClient initialized with model: {self.model}")
    
    async def generate(self,
                      prompt: str,
                      model: Optional[str] = None,
                      temperature: float = 0.7,
                      max_tokens: int = 2000,
                      system_prompt: Optional[str] = None,
                      **kwargs) -> str:
        """
        生成文本
        
        Args:
            prompt: 用户提示词
            model: 模型名称（可选，使用默认）
            temperature: 温度参数
            max_tokens: 最大 token 数
            system_prompt: 系统提示词
            **kwargs: 其他参数
            
        Returns:
            生成的文本
        """
        model = model or self.model
        
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        
        try:
            response = await self.client.post(
                "/chat/completions",
                json={
                    "model": model,
                    "messages": messages,
                    "temperature": temperature,
                    "max_tokens": max_tokens,
                    **kwargs
                }
            )
            response.raise_for_status()
            
            data = response.json()
            generated_text = data["choices"][0]["message"]["content"]
            
            # 记录 token 使用量
            usage = data.get("usage", {})
            logger.debug(f"Tokens used: {usage.get('total_tokens', 'N/A')}")
            
            return generated_text
            
        except httpx.HTTPError as e:
            logger.error(f"LLM API error: {e}")
            raise
        except Exception as e:
            logger.error(f"Unexpected error in LLM generation: {e}")
            raise
    
    async def generate_stream(self,
                             prompt: str,
                             model: Optional[str] = None,
                             temperature: float = 0.7,
                             max_tokens: int = 2000,
                             **kwargs) -> AsyncGenerator[str, None]:
        """
        流式生成文本
        
        Args:
            prompt: 用户提示词
            model: 模型名称
            temperature: 温度参数
            max_tokens: 最大 token 数
            **kwargs: 其他参数
            
        Yields:
            生成的文本片段
        """
        model = model or self.model
        
        messages = [{"role": "user", "content": prompt}]
        
        try:
            async with self.client.stream(
                "POST",
                "/chat/completions",
                json={
                    "model": model,
                    "messages": messages,
                    "temperature": temperature,
                    "max_tokens": max_tokens,
                    "stream": True,
                    **kwargs
                }
            ) as response:
                response.raise_for_status()
                
                async for line in response.aiter_lines():
                    if line.startswith("data: "):
                        data = line[6:]
                        if data == "[DONE]":
                            break
                        
                        try:
                            import json
                            chunk = json.loads(data)
                            delta = chunk["choices"][0]["delta"]
                            if "content" in delta:
                                yield delta["content"]
                        except:
                            pass
                            
        except Exception as e:
            logger.error(f"Stream generation error: {e}")
            raise
    
    async def close(self):
        """关闭客户端"""
        await self.client.aclose()
    
    def __del__(self):
        """析构时关闭客户端"""
        try:
            import asyncio
            if asyncio.get_event_loop().is_running():
                asyncio.create_task(self.close())
        except:
            pass