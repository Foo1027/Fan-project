"""
图像生成客户端
封装对图像生成 API 的调用
"""

import os
from typing import Dict, Optional, Any
import httpx
from loguru import logger


class ImageClient:
    """
    图像生成客户端
    
    支持：
    - DALL-E API
    - Stable Diffusion API
    - 其他图像生成服务
    """
    
    def __init__(self,
                 api_key: Optional[str] = None,
                 base_url: Optional[str] = None,
                 model: Optional[str] = None):
        """
        初始化图像客户端
        
        Args:
            api_key: API Key
            base_url: API 基础 URL
            model: 默认模型
        """
        self.api_key = api_key or os.getenv("DALLE_API_KEY") or os.getenv("OPENAI_API_KEY")
        self.base_url = base_url or "https://api.openai.com/v1"
        self.model = model or os.getenv("DEFAULT_IMAGE_MODEL", "dall-e-3")
        
        # 初始化 HTTP 客户端
        self.client = httpx.AsyncClient(
            base_url=self.base_url,
            headers={"Authorization": f"Bearer {self.api_key}"},
            timeout=120.0,  # 图像生成需要更长的超时
        )
        
        logger.info(f"ImageClient initialized with model: {self.model}")
    
    async def generate(self,
                      prompt: str,
                      width: int = 1024,
                      height: int = 1024,
                      model: Optional[str] = None,
                      **kwargs) -> Dict[str, Any]:
        """
        生成图像
        
        Args:
            prompt: 图像描述提示词
            width: 图像宽度
            height: 图像高度
            model: 模型名称
            **kwargs: 其他参数
            
        Returns:
            包含图像 URL 和本地路径的字典
        """
        model = model or self.model
        
        # DALL-E 只支持特定尺寸
        if "dall-e" in model.lower():
            size = self._get_dalle_size(width, height)
        else:
            size = f"{width}x{height}"
        
        try:
            response = await self.client.post(
                "/images/generations",
                json={
                    "model": model,
                    "prompt": prompt,
                    "size": size,
                    "n": 1,
                    "response_format": "url",
                    **kwargs
                }
            )
            response.raise_for_status()
            
            data = response.json()
            image_url = data["data"][0]["url"]
            
            logger.success(f"Image generated successfully")
            
            return {
                "url": image_url,
                "local_path": None,  # 需要额外下载
                "prompt": prompt,
                "size": size,
            }
            
        except httpx.HTTPError as e:
            logger.error(f"Image generation API error: {e}")
            # 返回一个模拟结果用于测试
            return {
                "url": None,
                "local_path": None,
                "prompt": prompt,
                "size": size,
                "error": str(e),
            }
        except Exception as e:
            logger.error(f"Unexpected error in image generation: {e}")
            raise
    
    def _get_dalle_size(self, width: int, height: int) -> str:
        """获取 DALL-E 支持的尺寸"""
        # DALL-E-3 支持: 1024x1024, 1024x1792, 1792x1024
        # DALL-E-2 支持: 256x256, 512x512, 1024x1024
        
        if width == height:
            return "1024x1024"
        elif width > height:
            return "1792x1024"
        else:
            return "1024x1792"
    
    async def edit(self,
                  image_path: str,
                  prompt: str,
                  mask_path: Optional[str] = None,
                  **kwargs) -> Dict[str, Any]:
        """
        编辑图像
        
        Args:
            image_path: 原图像路径
            prompt: 编辑提示词
            mask_path: 遮罩路径（可选）
            **kwargs: 其他参数
            
        Returns:
            编辑后的图像信息
        """
        try:
            # 读取图像文件
            with open(image_path, "rb") as f:
                image_data = f.read()
            
            files = {
                "image": ("image.png", image_data, "image/png"),
            }
            
            if mask_path:
                with open(mask_path, "rb") as f:
                    mask_data = f.read()
                files["mask"] = ("mask.png", mask_data, "image/png")
            
            data = {
                "prompt": prompt,
                "n": 1,
                "size": "1024x1024",
            }
            
            response = await self.client.post(
                "/images/edits",
                files=files,
                data=data,
            )
            response.raise_for_status()
            
            result = response.json()
            return {
                "url": result["data"][0]["url"],
                "local_path": None,
                "prompt": prompt,
            }
            
        except Exception as e:
            logger.error(f"Image editing error: {e}")
            raise
    
    async def vary(self,
                  image_path: str,
                  n: int = 1,
                  **kwargs) -> Dict[str, Any]:
        """
        生成图像变体
        
        Args:
            image_path: 原图像路径
            n: 变体数量
            **kwargs: 其他参数
            
        Returns:
            变体图像信息
        """
        try:
            with open(image_path, "rb") as f:
                image_data = f.read()
            
            files = {
                "image": ("image.png", image_data, "image/png"),
            }
            
            data = {
                "n": n,
                "size": "1024x1024",
            }
            
            response = await self.client.post(
                "/images/variations",
                files=files,
                data=data,
            )
            response.raise_for_status()
            
            result = response.json()
            return {
                "urls": [item["url"] for item in result["data"]],
                "count": n,
            }
            
        except Exception as e:
            logger.error(f"Image variation error: {e}")
            raise
    
    async def close(self):
        """关闭客户端"""
        await self.client.aclose()
