"""
商品数据模型
"""

from typing import List, Dict, Optional, Any
from pydantic import BaseModel, Field
from datetime import datetime
from enum import Enum


class ProductCategory(str, Enum):
    """商品类别"""
    ELECTRONICS = "electronics"
    CLOTHING = "clothing"
    FOOD = "food"
    HOME = "home"
    BEAUTY = "beauty"
    SPORTS = "sports"
    BOOKS = "books"
    OTHER = "other"


class ProductAttribute(BaseModel):
    """商品属性"""
    name: str = Field(..., description="属性名称")
    value: str = Field(..., description="属性值")
    category: Optional[str] = Field(None, description="属性分类")


class Product(BaseModel):
    """商品模型"""
    
    # 基础信息
    id: str = Field(..., description="商品唯一ID")
    name: str = Field(..., description="商品名称")
    description: Optional[str] = Field(None, description="商品描述")
    category: ProductCategory = Field(default=ProductCategory.OTHER, description="商品类别")
    
    # 价格和库存
    price: float = Field(..., description="商品价格")
    original_price: Optional[float] = Field(None, description="原价")
    currency: str = Field(default="CNY", description="货币单位")
    stock: Optional[int] = Field(None, description="库存数量")
    
    # 详细属性
    attributes: List[ProductAttribute] = Field(default_factory=list, description="商品属性列表")
    features: List[str] = Field(default_factory=list, description="商品卖点/特性")
    specifications: Dict[str, Any] = Field(default_factory=dict, description="技术规格")
    
    # 媒体资源
    images: List[str] = Field(default_factory=list, description="商品图片URL列表")
    videos: List[str] = Field(default_factory=list, description="商品视频URL列表")
    
    # 品牌和来源
    brand: Optional[str] = Field(None, description="品牌名称")
    source_url: Optional[str] = Field(None, description="来源链接")
    
    # 目标受众
    target_audience: Optional[str] = Field(None, description="目标受众描述")
    use_cases: List[str] = Field(default_factory=list, description="使用场景")
    
    # 元数据
    created_at: datetime = Field(default_factory=datetime.now, description="创建时间")
    updated_at: datetime = Field(default_factory=datetime.now, description="更新时间")
    tags: List[str] = Field(default_factory=list, description="标签")
    
    class Config:
        json_schema_extra = {
            "example": {
                "id": "PROD-001",
                "name": "智能降噪无线耳机 Pro",
                "description": "采用最新主动降噪技术，40小时超长续航",
                "category": "electronics",
                "price": 899.0,
                "original_price": 1299.0,
                "currency": "CNY",
                "stock": 500,
                "attributes": [
                    {"name": "颜色", "value": "星空黑", "category": "外观"},
                    {"name": "重量", "value": "250g", "category": "物理"},
                    {"name": "续航", "value": "40小时", "category": "性能"},
                ],
                "features": [
                    "主动降噪深度达45dB",
                    "支持多设备无缝切换",
                    "IPX7级防水防汗",
                    "触控操作，支持语音助手"
                ],
                "brand": "TechSound",
                "target_audience": "追求音质的年轻白领和运动爱好者",
                "use_cases": ["通勤", "运动", "办公", "旅行"],
            }
        }
    
    def to_prompt_text(self) -> str:
        """转换为用于 LLM 的文本描述"""
        lines = [
            f"商品名称: {self.name}",
            f"品牌: {self.brand or '未知'}",
            f"类别: {self.category.value}",
            f"价格: {self.currency} {self.price}",
        ]
        
        if self.original_price:
            lines.append(f"原价: {self.currency} {self.original_price}")
        
        if self.description:
            lines.append(f"\n商品描述: {self.description}")
        
        if self.features:
            lines.append("\n核心卖点:")
            for feature in self.features:
                lines.append(f"  - {feature}")
        
        if self.attributes:
            lines.append("\n商品属性:")
            for attr in self.attributes:
                lines.append(f"  - {attr.name}: {attr.value}")
        
        if self.target_audience:
            lines.append(f"\n目标受众: {self.target_audience}")
        
        if self.use_cases:
            lines.append(f"适用场景: {', '.join(self.use_cases)}")
        
        return "\n".join(lines)
    
    def get_discount_info(self) -> Optional[str]:
        """获取折扣信息"""
        if self.original_price and self.original_price > self.price:
            discount = (1 - self.price / self.original_price) * 100
            return f"限时{discount:.0f}%OFF"
        return None