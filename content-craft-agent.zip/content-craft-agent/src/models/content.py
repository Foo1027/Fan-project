"""
内容数据模型
"""

from typing import List, Dict, Optional, Any
from pydantic import BaseModel, Field
from datetime import datetime
from enum import Enum


class ContentType(str, Enum):
    """内容类型"""
    TITLE = "title"           # 标题
    HEADLINE = "headline"     # 主标题
    SUBTITLE = "subtitle"     # 副标题
    DESCRIPTION = "description"  # 描述
    SLOGAN = "slogan"         # 标语
    STORY = "story"           # 故事
    DETAIL = "detail"         # 详情
    REVIEW = "review"         # 评价
    SOCIAL = "social"         # 社交媒体文案


class ContentStyle(str, Enum):
    """文案风格"""
    MARKETING = "marketing"   # 营销型：强调促销、紧迫感
    PROFESSIONAL = "professional"  # 专业型：强调技术、参数
    STORY = "story"           # 故事型：情感化、场景化
    MINIMAL = "minimal"       # 简约型：简洁、高端
    FUN = "fun"               # 趣味型：轻松、幽默
    LUXURY = "luxury"         # 奢华型：高端、品质感


class ContentPiece(BaseModel):
    """单条内容片段"""
    
    id: str = Field(..., description="内容ID")
    type: ContentType = Field(..., description="内容类型")
    style: ContentStyle = Field(..., description="文案风格")
    text: str = Field(..., description="内容文本")
    
    # 关联信息
    product_id: str = Field(..., description="关联商品ID")
    version: int = Field(default=1, description="版本号")
    
    # 效果数据（用于 A/B 测试）
    impressions: int = Field(default=0, description="曝光量")
    clicks: int = Field(default=0, description="点击量")
    conversions: int = Field(default=0, description="转化量")
    ctr: Optional[float] = Field(None, description="点击率")
    
    # 元数据
    created_at: datetime = Field(default_factory=datetime.now, description="创建时间")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="额外元数据")
    
    def calculate_ctr(self) -> float:
        """计算点击率"""
        if self.impressions > 0:
            self.ctr = self.clicks / self.impressions
            return self.ctr
        return 0.0
    
    def update_metrics(self, impressions: int = 0, clicks: int = 0, conversions: int = 0):
        """更新效果指标"""
        self.impressions += impressions
        self.clicks += clicks
        self.conversions += conversions
        self.calculate_ctr()


class GeneratedImage(BaseModel):
    """生成的图片"""
    
    id: str = Field(..., description="图片ID")
    url: Optional[str] = Field(None, description="图片URL")
    local_path: Optional[str] = Field(None, description="本地路径")
    prompt: str = Field(..., description="生成提示词")
    style: Optional[str] = Field(None, description="图片风格")
    
    # 关联信息
    product_id: str = Field(..., description="关联商品ID")
    content_id: Optional[str] = Field(None, description="关联文案ID")
    
    # 效果数据
    impressions: int = Field(default=0, description="曝光量")
    clicks: int = Field(default=0, description="点击量")
    
    created_at: datetime = Field(default_factory=datetime.now, description="创建时间")


class ContentSet(BaseModel):
    """内容集合（一套完整的内容）"""
    
    id: str = Field(..., description="集合ID")
    product_id: str = Field(..., description="关联商品ID")
    name: str = Field(..., description="集合名称")
    
    # 内容组合
    headline: Optional[ContentPiece] = Field(None, description="主标题")
    subheadline: Optional[ContentPiece] = Field(None, description="副标题")
    description: Optional[ContentPiece] = Field(None, description="描述文案")
    story: Optional[ContentPiece] = Field(None, description="故事文案")
    slogans: List[ContentPiece] = Field(default_factory=list, description="标语列表")
    social_posts: List[ContentPiece] = Field(default_factory=list, description="社交媒体文案")
    
    # 配图
    images: List[GeneratedImage] = Field(default_factory=list, description="配图列表")
    
    # 整体风格
    primary_style: ContentStyle = Field(default=ContentStyle.MARKETING, description="主要风格")
    
    # A/B 测试
    is_variant: bool = Field(default=False, description="是否为变体版本")
    parent_id: Optional[str] = Field(None, description="父版本ID")
    variant_name: Optional[str] = Field(None, description="变体名称（如 A版、B版）")
    
    # 效果数据
    total_impressions: int = Field(default=0, description="总曝光")
    total_clicks: int = Field(default=0, description="总点击")
    total_conversions: int = Field(default=0, description="总转化")
    overall_ctr: Optional[float] = Field(None, description="整体点击率")
    
    created_at: datetime = Field(default_factory=datetime.now, description="创建时间")
    updated_at: datetime = Field(default_factory=datetime.now, description="更新时间")
    
    def calculate_overall_metrics(self):
        """计算整体指标"""
        all_content = []
        if self.headline:
            all_content.append(self.headline)
        if self.subheadline:
            all_content.append(self.subheadline)
        if self.description:
            all_content.append(self.description)
        all_content.extend(self.slogans)
        all_content.extend(self.social_posts)
        
        self.total_impressions = sum(c.impressions for c in all_content)
        self.total_clicks = sum(c.clicks for c in all_content)
        self.total_conversions = sum(c.conversions for c in all_content)
        
        if self.total_impressions > 0:
            self.overall_ctr = self.total_clicks / self.total_impressions
    
    def get_best_performing(self, metric: str = "ctr") -> Optional[ContentPiece]:
        """获取表现最好的内容"""
        all_content = []
        if self.headline:
            all_content.append(self.headline)
        all_content.extend(self.slogans)
        all_content.extend(self.social_posts)
        
        if not all_content:
            return None
        
        if metric == "ctr":
            return max(all_content, key=lambda x: x.ctr or 0)
        elif metric == "clicks":
            return max(all_content, key=lambda x: x.clicks)
        elif metric == "conversions":
            return max(all_content, key=lambda x: x.conversions)
        
        return None
    
    def to_dict(self) -> Dict[str, Any]:
        """导出为字典格式"""
        return {
            "id": self.id,
            "product_id": self.product_id,
            "name": self.name,
            "headline": self.headline.text if self.headline else None,
            "subheadline": self.subheadline.text if self.subheadline else None,
            "description": self.description.text if self.description else None,
            "story": self.story.text if self.story else None,
            "slogans": [s.text for s in self.slogans],
            "social_posts": [s.text for s in self.social_posts],
            "images": [img.url or img.local_path for img in self.images],
            "style": self.primary_style.value,
            "metrics": {
                "impressions": self.total_impressions,
                "clicks": self.total_clicks,
                "conversions": self.total_conversions,
                "ctr": self.overall_ctr,
            }
        }