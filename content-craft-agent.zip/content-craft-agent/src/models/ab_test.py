"""
A/B 测试数据模型
"""

from typing import List, Dict, Optional, Any
from pydantic import BaseModel, Field
from datetime import datetime
from enum import Enum


class TestStatus(str, Enum):
    """测试状态"""
    PENDING = "pending"       # 待开始
    RUNNING = "running"       # 进行中
    PAUSED = "paused"         # 已暂停
    COMPLETED = "completed"   # 已完成
    CANCELLED = "cancelled"   # 已取消


class TestMetric(str, Enum):
    """测试指标"""
    CTR = "ctr"               # 点击率
    CONVERSION = "conversion" # 转化率
    ENGAGEMENT = "engagement" # 参与度
    REVENUE = "revenue"       # 收入


class ABTestVariant(BaseModel):
    """A/B 测试变体"""
    
    id: str = Field(..., description="变体ID")
    name: str = Field(..., description="变体名称（如 A版、B版）")
    content_set_id: str = Field(..., description="关联内容集合ID")
    
    # 流量分配
    traffic_percentage: float = Field(default=50.0, description="流量分配百分比")
    
    # 效果数据
    impressions: int = Field(default=0, description="曝光量")
    clicks: int = Field(default=0, description="点击量")
    conversions: int = Field(default=0, description="转化量")
    revenue: float = Field(default=0.0, description="收入")
    
    # 计算指标
    ctr: Optional[float] = Field(None, description="点击率")
    conversion_rate: Optional[float] = Field(None, description="转化率")
    
    def calculate_metrics(self):
        """计算指标"""
        if self.impressions > 0:
            self.ctr = self.clicks / self.impressions
        if self.clicks > 0:
            self.conversion_rate = self.conversions / self.clicks
    
    def is_winner(self, control_ctr: float, confidence_level: float = 0.95) -> bool:
        """
        判断是否为获胜变体
        简化版：如果 CTR 显著高于对照组则获胜
        """
        if self.ctr is None or control_ctr == 0:
            return False
        # 简化判断：提升超过 10% 认为显著
        lift = (self.ctr - control_ctr) / control_ctr
        return lift > 0.1


class ABTest(BaseModel):
    """A/B 测试"""
    
    id: str = Field(..., description="测试ID")
    name: str = Field(..., description="测试名称")
    description: Optional[str] = Field(None, description="测试描述")
    
    # 关联信息
    product_id: str = Field(..., description="关联商品ID")
    
    # 变体
    control_variant: ABTestVariant = Field(..., description="对照组（A版）")
    treatment_variants: List[ABTestVariant] = Field(default_factory=list, description="实验组（B版及更多）")
    
    # 测试配置
    primary_metric: TestMetric = Field(default=TestMetric.CTR, description="主要测试指标")
    min_sample_size: int = Field(default=1000, description="最小样本量")
    confidence_level: float = Field(default=0.95, description="置信水平")
    
    # 状态
    status: TestStatus = Field(default=TestStatus.PENDING, description="测试状态")
    
    # 时间
    start_time: Optional[datetime] = Field(None, description="开始时间")
    end_time: Optional[datetime] = Field(None, description="结束时间")
    duration_days: int = Field(default=7, description="计划测试天数")
    
    # 结果
    winner_variant_id: Optional[str] = Field(None, description="获胜变体ID")
    result_summary: Optional[str] = Field(None, description="结果摘要")
    
    created_at: datetime = Field(default_factory=datetime.now, description="创建时间")
    updated_at: datetime = Field(default_factory=datetime.now, description="更新时间")
    
    def start(self):
        """开始测试"""
        self.status = TestStatus.RUNNING
        self.start_time = datetime.now()
    
    def pause(self):
        """暂停测试"""
        self.status = TestStatus.PAUSED
    
    def complete(self, winner_id: Optional[str] = None):
        """完成测试"""
        self.status = TestStatus.COMPLETED
        self.end_time = datetime.now()
        self.winner_variant_id = winner_id
        
        # 计算所有变体指标
        self.control_variant.calculate_metrics()
        for variant in self.treatment_variants:
            variant.calculate_metrics()
        
        # 生成结果摘要
        self._generate_summary()
    
    def _generate_summary(self):
        """生成结果摘要"""
        control = self.control_variant
        control.calculate_metrics()
        
        lines = [
            f"A/B 测试结果: {self.name}",
            f"主要指标: {self.primary_metric.value}",
            f"\n对照组 ({control.name}):",
            f"  - 曝光: {control.impressions}",
            f"  - 点击: {control.clicks}",
            f"  - CTR: {control.ctr:.2%}" if control.ctr else "  - CTR: N/A",
        ]
        
        for variant in self.treatment_variants:
            variant.calculate_metrics()
            lines.extend([
                f"\n实验组 ({variant.name}):",
                f"  - 曝光: {variant.impressions}",
                f"  - 点击: {variant.clicks}",
                f"  - CTR: {variant.ctr:.2%}" if variant.ctr else "  - CTR: N/A",
            ])
            
            if control.ctr and variant.ctr:
                lift = (variant.ctr - control.ctr) / control.ctr
                lines.append(f"  - 相对提升: {lift:+.1%}")
        
        if self.winner_variant_id:
            winner = self.get_variant_by_id(self.winner_variant_id)
            if winner:
                lines.append(f"\n🏆 获胜变体: {winner.name}")
        
        self.result_summary = "\n".join(lines)
    
    def get_variant_by_id(self, variant_id: str) -> Optional[ABTestVariant]:
        """根据ID获取变体"""
        if self.control_variant.id == variant_id:
            return self.control_variant
        for variant in self.treatment_variants:
            if variant.id == variant_id:
                return variant
        return None
    
    def get_best_variant(self) -> Optional[ABTestVariant]:
        """获取表现最好的变体"""
        all_variants = [self.control_variant] + self.treatment_variants
        
        if self.primary_metric == TestMetric.CTR:
            return max(all_variants, key=lambda x: x.ctr or 0)
        elif self.primary_metric == TestMetric.CONVERSION:
            return max(all_variants, key=lambda x: x.conversion_rate or 0)
        elif self.primary_metric == TestMetric.REVENUE:
            return max(all_variants, key=lambda x: x.revenue)
        
        return None
    
    def update_metrics(self, variant_id: str, impressions: int = 0, clicks: int = 0, 
                      conversions: int = 0, revenue: float = 0.0):
        """更新变体指标"""
        variant = self.get_variant_by_id(variant_id)
        if variant:
            variant.impressions += impressions
            variant.clicks += clicks
            variant.conversions += conversions
            variant.revenue += revenue
            variant.calculate_metrics()
            self.updated_at = datetime.now()
    
    def should_stop_early(self) -> bool:
        """是否应该提前停止测试（达到统计显著性）"""
        # 简化版：如果某个变体显著优于对照组，可以提前停止
        control = self.control_variant
        control.calculate_metrics()
        
        if control.ctr is None:
            return False
        
        for variant in self.treatment_variants:
            variant.calculate_metrics()
            if variant.ctr and variant.is_winner(control.ctr, self.confidence_level):
                return True
        
        return False


class ABTestResult(BaseModel):
    """A/B 测试结果报告"""
    
    test_id: str = Field(..., description="测试ID")
    test_name: str = Field(..., description="测试名称")
    
    # 统计结果
    winner_variant: Optional[str] = Field(None, description="获胜变体名称")
    confidence: Optional[float] = Field(None, description="置信度")
    lift_percentage: Optional[float] = Field(None, description="提升百分比")
    
    # 详细数据
    control_metrics: Dict[str, Any] = Field(default_factory=dict, description="对照组指标")
    treatment_metrics: List[Dict[str, Any]] = Field(default_factory=list, description="实验组指标")
    
    # 建议
    recommendations: List[str] = Field(default_factory=list, description="优化建议")
    
    # 时间
    generated_at: datetime = Field(default_factory=datetime.now, description="生成时间")
    
    @classmethod
    def from_test(cls, test: ABTest) -> "ABTestResult":
        """从测试对象生成结果报告"""
        result = cls(
            test_id=test.id,
            test_name=test.name,
        )
        
        # 设置获胜变体
        if test.winner_variant_id:
            winner = test.get_variant_by_id(test.winner_variant_id)
            if winner:
                result.winner_variant = winner.name
        
        # 设置对照组指标
        control = test.control_variant
        control.calculate_metrics()
        result.control_metrics = {
            "name": control.name,
            "impressions": control.impressions,
            "clicks": control.clicks,
            "ctr": control.ctr,
            "conversions": control.conversions,
            "conversion_rate": control.conversion_rate,
        }
        
        # 设置实验组指标
        for variant in test.treatment_variants:
            variant.calculate_metrics()
            metrics = {
                "name": variant.name,
                "impressions": variant.impressions,
                "clicks": variant.clicks,
                "ctr": variant.ctr,
                "conversions": variant.conversions,
                "conversion_rate": variant.conversion_rate,
            }
            
            # 计算相对提升
            if control.ctr and variant.ctr:
                metrics["ctr_lift"] = (variant.ctr - control.ctr) / control.ctr
            
            result.treatment_metrics.append(metrics)
        
        # 生成建议
        result._generate_recommendations(test)
        
        return result
    
    def _generate_recommendations(self, test: ABTest):
        """生成优化建议"""
        recommendations = []
        
        best = test.get_best_variant()
        control = test.control_variant
        
        if best and best.id != control.id:
            lift = 0
            if control.ctr and best.ctr:
                lift = (best.ctr - control.ctr) / control.ctr
            
            recommendations.append(
                f"建议采用「{best.name}」作为主力版本，"
                f"预计 CTR 可提升 {lift:.1%}"
            )
        
        # 样本量建议
        total_impressions = sum(
            v.impressions for v in [control] + test.treatment_variants
        )
        if total_impressions < test.min_sample_size:
            recommendations.append(
                f"当前样本量({total_impressions})未达到最小要求({test.min_sample_size})，"
                f"建议继续收集数据"
            )
        
        # 流量分配建议
        if test.treatment_variants:
            best_traffic = test.treatment_variants[0].traffic_percentage
            if best_traffic < 50:
                recommendations.append(
                    "建议将更多流量分配给实验组以加速测试"
                )
        
        self.recommendations = recommendations