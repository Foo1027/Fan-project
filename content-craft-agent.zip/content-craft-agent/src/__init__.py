"""
ContentCraft Agent - 多模态内容生产 Agent 系统
"""

__version__ = "0.1.0"
__author__ = "ContentCraft Team"

from .agents.orchestrator import ContentOrchestrator
from .models.product import Product
from .models.content import ContentPiece, ContentSet

__all__ = [
    "ContentOrchestrator",
    "Product", 
    "ContentPiece",
    "ContentSet",
]