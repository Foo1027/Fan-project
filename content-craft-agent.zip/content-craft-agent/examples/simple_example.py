"""
简单使用示例
展示 ContentCraft Agent 的基本用法
"""

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.agents.orchestrator import ContentOrchestrator
from src.models.product import Product, ProductAttribute, ProductCategory
from src.models.content import ContentStyle


async def main():
    """简单示例"""
    
    # 1. 初始化编排器
    orchestrator = ContentOrchestrator()
    
    # 2. 创建商品信息
    product = Product(
        id="PROD-001",
        name="智能手环 Pro",
        description="24小时健康监测，14天超长续航",
        category=ProductCategory.ELECTRONICS,
        price=399.0,
        brand="HealthTech",
        features=[
            "心率血氧双监测",
            "睡眠分析",
            "50米防水",
            "14天续航"
        ],
        target_audience="关注健康的年轻人群",
        use_cases=["运动健身", "日常健康监测"],
    )
    
    # 3. 生成内容
    print("正在生成内容...")
    result = await orchestrator.process_product(
        product,
        mode="simple",  # 简单模式：仅文案
        style=ContentStyle.MARKETING
    )
    
    # 4. 查看结果
    content_set = result["content_sets"][0]
    
    print("\n" + "="*50)
    print("生成的内容：")
    print("="*50)
    
    print(f"\n📝 主标题：")
    print(content_set.headline.text)
    
    print(f"\n📝 副标题：")
    print(content_set.subheadline.text)
    
    print(f"\n📝 商品描述：")
    print(content_set.description.text)
    
    print(f"\n📝 标语：")
    for slogan in content_set.slogans:
        print(f"  • {slogan.text}")
    
    print(f"\n📝 社交媒体文案：")
    for post in content_set.social_posts:
        print(f"  • {post.text[:80]}...")
    
    print("\n" + "="*50)
    print("✅ 内容生成完成！")


if __name__ == "__main__":
    asyncio.run(main())