"""
ContentCraft Agent 演示脚本
展示如何使用多模态内容生产 Agent 系统
"""

import asyncio
import sys
from pathlib import Path

# 添加项目根目录到路径
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.agents.orchestrator import ContentOrchestrator
from src.models.product import Product, ProductAttribute, ProductCategory
from src.models.content import ContentStyle


async def demo_simple_mode():
    """演示简单模式：仅生成文案"""
    print("\n" + "="*60)
    print("演示 1: 简单模式 - 仅生成文案")
    print("="*60)
    
    # 初始化编排器
    orchestrator = ContentOrchestrator()
    
    # 创建示例商品
    product = Product(
        id="PROD-DEMO-001",
        name="智能降噪无线耳机 Pro",
        description="采用最新主动降噪技术，40小时超长续航，音质出众",
        category=ProductCategory.ELECTRONICS,
        price=899.0,
        original_price=1299.0,
        brand="TechSound",
        features=[
            "主动降噪深度达45dB",
            "支持多设备无缝切换",
            "IPX7级防水防汗",
            "触控操作，支持语音助手",
            "40小时超长续航"
        ],
        attributes=[
            ProductAttribute(name="颜色", value="星空黑", category="外观"),
            ProductAttribute(name="重量", value="250g", category="物理"),
            ProductAttribute(name="续航", value="40小时", category="性能"),
            ProductAttribute(name="连接方式", value="蓝牙5.3", category="技术"),
        ],
        target_audience="追求音质的年轻白领和运动爱好者",
        use_cases=["通勤", "运动", "办公", "旅行"],
    )
    
    print(f"\n商品信息：")
    print(f"  名称: {product.name}")
    print(f"  品牌: {product.brand}")
    print(f"  价格: ¥{product.price} (原价 ¥{product.original_price})")
    print(f"  目标受众: {product.target_audience}")
    
    # 处理商品
    result = await orchestrator.process_product(
        product,
        mode="simple",
        style=ContentStyle.MARKETING
    )
    
    # 显示结果
    content_set = result["content_sets"][0]
    print(f"\n✅ 生成的内容：")
    print(f"\n📌 主标题：")
    print(f"   {content_set.headline.text if content_set.headline else 'N/A'}")
    
    print(f"\n📌 副标题：")
    print(f"   {content_set.subheadline.text if content_set.subheadline else 'N/A'}")
    
    print(f"\n📌 商品描述：")
    print(f"   {content_set.description.text[:150] if content_set.description else 'N/A'}...")
    
    print(f"\n📌 标语：")
    for i, slogan in enumerate(content_set.slogans[:3], 1):
        print(f"   {i}. {slogan.text}")
    
    print(f"\n📌 社交媒体文案：")
    for i, post in enumerate(content_set.social_posts[:2], 1):
        print(f"   {i}. {post.text[:100]}...")
    
    return result


async def demo_complete_mode():
    """演示完整模式：文案 + 图像"""
    print("\n" + "="*60)
    print("演示 2: 完整模式 - 文案 + 图像")
    print("="*60)
    
    orchestrator = ContentOrchestrator()
    
    # 创建另一个示例商品
    product = Product(
        id="PROD-DEMO-002",
        name="天然有机绿茶",
        description="产自高山茶园，手工采摘，清香回甘",
        category=ProductCategory.FOOD,
        price=128.0,
        original_price=168.0,
        brand="云雾茶庄",
        features=[
            "高山茶园直供",
            "手工采摘，一芽一叶",
            "无农药残留",
            "清香回甘，汤色明亮"
        ],
        attributes=[
            ProductAttribute(name="产地", value="福建武夷山", category="地理"),
            ProductAttribute(name="净含量", value="250g", category="规格"),
            ProductAttribute(name="等级", value="特级", category="品质"),
        ],
        target_audience="注重健康的中高端消费者，茶文化爱好者",
        use_cases=["日常饮用", "商务招待", "送礼"],
    )
    
    print(f"\n商品信息：")
    print(f"  名称: {product.name}")
    print(f"  品牌: {product.brand}")
    print(f"  价格: ¥{product.price}")
    
    # 处理商品（完整模式）
    result = await orchestrator.process_product(
        product,
        mode="complete",
        style=ContentStyle.STORY
    )
    
    content_set = result["content_sets"][0]
    
    print(f"\n✅ 生成的内容：")
    print(f"\n📌 主标题：{content_set.headline.text if content_set.headline else 'N/A'}")
    
    print(f"\n📌 故事文案：")
    if content_set.story:
        print(f"   {content_set.story.text[:200]}...")
    
    print(f"\n📌 生成的图像：")
    print(f"   共生成 {len(content_set.images)} 张图像")
    for img in content_set.images:
        print(f"   - {img.style}风格: {img.id}")
    
    return result


async def demo_batch_processing():
    """演示批量处理"""
    print("\n" + "="*60)
    print("演示 3: 批量处理多个商品")
    print("="*60)
    
    orchestrator = ContentOrchestrator()
    
    # 创建多个示例商品
    products = [
        {
            "name": "便携式蓝牙音箱",
            "description": "小巧便携，360度环绕音效，防水设计",
            "category": "electronics",
            "price": 299.0,
            "brand": "SoundMini",
        },
        {
            "name": "纯棉舒适T恤",
            "description": "100%新疆长绒棉，亲肤透气，不易变形",
            "category": "clothing",
            "price": 89.0,
            "brand": "ComfortWear",
        },
        {
            "name": "智能保温杯",
            "description": "温度显示，24小时保温，316不锈钢内胆",
            "category": "home",
            "price": 159.0,
            "brand": "SmartLife",
        },
    ]
    
    print(f"\n准备处理 {len(products)} 个商品...")
    
    # 批量处理
    results = await orchestrator.process_batch(
        products,
        mode="simple",
        max_concurrency=2
    )
    
    print(f"\n✅ 批量处理完成！")
    for i, result in enumerate(results, 1):
        if isinstance(result, Exception):
            print(f"   商品 {i}: ❌ 失败 - {result}")
        else:
            product_name = result["product"].name if result["product"] else "Unknown"
            content_count = len(result["content_sets"])
            print(f"   商品 {i}: ✅ {product_name} - 生成 {content_count} 套内容")
    
    return results


async def demo_platform_content():
    """演示为特定平台生成内容"""
    print("\n" + "="*60)
    print("演示 4: 为特定平台生成优化内容")
    print("="*60)
    
    orchestrator = ContentOrchestrator()
    
    product = Product(
        id="PROD-DEMO-004",
        name="网红ins风台灯",
        description="北欧简约设计，三色温可调，护眼LED光源",
        category=ProductCategory.HOME,
        price=199.0,
        brand="NordicLight",
        features=[
            "北欧简约设计",
            "三色温可调",
            "无频闪护眼",
            "USB充电便携"
        ],
        target_audience="年轻租房族，追求生活品质的都市白领",
        use_cases=["卧室床头", "书桌阅读", "氛围营造"],
    )
    
    platforms = ["xiaohongshu", "weibo", "taobao"]
    
    for platform in platforms:
        print(f"\n📱 为 {platform} 平台生成内容：")
        
        content_set = await orchestrator.generate_content_for_platform(
            product, platform
        )
        
        print(f"   主标题: {content_set.headline.text[:30]}...")
        print(f"   生成图像: {len(content_set.images)} 张")
        if content_set.social_posts:
            print(f"   社交文案: {content_set.social_posts[0].text[:50]}...")


async def main():
    """主函数"""
    print("\n" + "="*60)
    print("🎨 ContentCraft Agent 演示")
    print("多模态内容生产 Agent 系统")
    print("="*60)
    
    try:
        # 运行各个演示
        await demo_simple_mode()
        # await demo_complete_mode()  # 需要图像API
        await demo_batch_processing()
        # await demo_platform_content()  # 需要图像API
        
        print("\n" + "="*60)
        print("✨ 所有演示完成！")
        print("="*60)
        
    except Exception as e:
        print(f"\n❌ 演示出错: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    # 运行异步主函数
    asyncio.run(main())