"""
商品模型测试
"""

import pytest
from src.models.product import Product, ProductAttribute, ProductCategory


def test_product_creation():
    """测试商品创建"""
    product = Product(
        id="TEST-001",
        name="测试商品",
        price=100.0,
        category=ProductCategory.ELECTRONICS,
    )
    
    assert product.id == "TEST-001"
    assert product.name == "测试商品"
    assert product.price == 100.0
    assert product.category == ProductCategory.ELECTRONICS


def test_product_to_prompt_text():
    """测试商品信息转换为提示词文本"""
    product = Product(
        id="TEST-002",
        name="智能手表",
        description="高端智能手表",
        price=999.0,
        original_price=1299.0,
        brand="TechBrand",
        category=ProductCategory.ELECTRONICS,
        features=["功能1", "功能2", "功能3"],
        attributes=[
            ProductAttribute(name="颜色", value="黑色"),
            ProductAttribute(name="重量", value="50g"),
        ],
        target_audience="年轻人群",
        use_cases=["运动", "办公"],
    )
    
    text = product.to_prompt_text()
    
    assert "智能手表" in text
    assert "TechBrand" in text
    assert "999.0" in text
    assert "功能1" in text
    assert "年轻人群" in text


def test_discount_info():
    """测试折扣信息计算"""
    # 有折扣的情况
    product_with_discount = Product(
        id="TEST-003",
        name="打折商品",
        price=80.0,
        original_price=100.0,
    )
    
    discount = product_with_discount.get_discount_info()
    assert discount is not None
    assert "20%" in discount or "限时" in discount
    
    # 无折扣的情况
    product_no_discount = Product(
        id="TEST-004",
        name="原价商品",
        price=100.0,
    )
    
    discount = product_no_discount.get_discount_info()
    assert discount is None


def test_product_attributes():
    """测试商品属性"""
    attr = ProductAttribute(
        name="尺寸",
        value="10cm",
        category="物理"
    )
    
    assert attr.name == "尺寸"
    assert attr.value == "10cm"
    assert attr.category == "物理"


def test_product_category_enum():
    """测试商品类别枚举"""
    assert ProductCategory.ELECTRONICS.value == "electronics"
    assert ProductCategory.CLOTHING.value == "clothing"
    assert ProductCategory.FOOD.value == "food"