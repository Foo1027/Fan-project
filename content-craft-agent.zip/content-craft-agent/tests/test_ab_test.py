"""
A/B 测试模型测试
"""

import pytest
from datetime import datetime
from src.models.ab_test import ABTest, ABTestVariant, ABTestResult, TestMetric, TestStatus


def test_ab_test_variant_creation():
    """测试变体创建"""
    variant = ABTestVariant(
        id="VAR-001",
        name="A版",
        content_set_id="CONTENT-001",
        traffic_percentage=50,
    )
    
    assert variant.id == "VAR-001"
    assert variant.name == "A版"
    assert variant.traffic_percentage == 50


def test_variant_metrics_calculation():
    """测试变体指标计算"""
    variant = ABTestVariant(
        id="VAR-002",
        name="B版",
        content_set_id="CONTENT-002",
        impressions=1000,
        clicks=100,
        conversions=10,
    )
    
    variant.calculate_metrics()
    
    assert variant.ctr == 0.10
    assert variant.conversion_rate == 0.10


def test_variant_winner_detection():
    """测试获胜变体检测"""
    variant = ABTestVariant(
        id="VAR-003",
        name="C版",
        content_set_id="CONTENT-003",
        impressions=1000,
        clicks=150,  # 15% CTR
    )
    
    variant.calculate_metrics()
    
    # 相对于 10% CTR 的对照组，提升 50%，应该获胜
    assert variant.is_winner(0.10) == True
    
    # 相对于 14% CTR 的对照组，提升不足 10%，不应该获胜
    assert variant.is_winner(0.14) == False


def test_ab_test_creation():
    """测试 A/B 测试创建"""
    control = ABTestVariant(
        id="VAR-A",
        name="对照组",
        content_set_id="CONTENT-A",
    )
    
    treatment = ABTestVariant(
        id="VAR-B",
        name="实验组",
        content_set_id="CONTENT-B",
    )
    
    test = ABTest(
        id="TEST-001",
        name="标题测试",
        product_id="PROD-001",
        control_variant=control,
        treatment_variants=[treatment],
        primary_metric=TestMetric.CTR,
    )
    
    assert test.id == "TEST-001"
    assert test.status == TestStatus.PENDING
    assert test.primary_metric == TestMetric.CTR


def test_ab_test_lifecycle():
    """测试 A/B 测试生命周期"""
    control = ABTestVariant(id="VAR-A", name="对照组", content_set_id="CONTENT-A")
    treatment = ABTestVariant(id="VAR-B", name="实验组", content_set_id="CONTENT-B")
    
    test = ABTest(
        id="TEST-002",
        name="生命周期测试",
        product_id="PROD-001",
        control_variant=control,
        treatment_variants=[treatment],
    )
    
    # 启动测试
    test.start()
    assert test.status == TestStatus.RUNNING
    assert test.start_time is not None
    
    # 暂停测试
    test.pause()
    assert test.status == TestStatus.PAUSED
    
    # 完成测试
    test.complete(winner_id="VAR-B")
    assert test.status == TestStatus.COMPLETED
    assert test.winner_variant_id == "VAR-B"
    assert test.end_time is not None


def test_ab_test_metrics_update():
    """测试 A/B 测试指标更新"""
    control = ABTestVariant(id="VAR-A", name="对照组", content_set_id="CONTENT-A")
    treatment = ABTestVariant(id="VAR-B", name="实验组", content_set_id="CONTENT-B")
    
    test = ABTest(
        id="TEST-003",
        name="指标更新测试",
        product_id="PROD-001",
        control_variant=control,
        treatment_variants=[treatment],
    )
    
    # 更新对照组指标
    test.update_metrics("VAR-A", impressions=1000, clicks=100)
    
    # 更新实验组指标
    test.update_metrics("VAR-B", impressions=1000, clicks=120)
    
    assert test.control_variant.impressions == 1000
    assert test.control_variant.clicks == 100
    assert test.treatment_variants[0].clicks == 120


def test_get_best_variant():
    """测试获取最佳变体"""
    control = ABTestVariant(
        id="VAR-A",
        name="对照组",
        content_set_id="CONTENT-A",
        impressions=1000,
        clicks=100,  # 10% CTR
    )
    control.calculate_metrics()
    
    treatment = ABTestVariant(
        id="VAR-B",
        name="实验组",
        content_set_id="CONTENT-B",
        impressions=1000,
        clicks=150,  # 15% CTR
    )
    treatment.calculate_metrics()
    
    test = ABTest(
        id="TEST-004",
        name="最佳变体测试",
        product_id="PROD-001",
        control_variant=control,
        treatment_variants=[treatment],
        primary_metric=TestMetric.CTR,
    )
    
    best = test.get_best_variant()
    assert best.id == "VAR-B"


def test_ab_test_result_from_test():
    """测试从测试生成结果报告"""
    control = ABTestVariant(
        id="VAR-A",
        name="对照组",
        content_set_id="CONTENT-A",
        impressions=1000,
        clicks=100,
    )
    
    treatment = ABTestVariant(
        id="VAR-B",
        name="实验组",
        content_set_id="CONTENT-B",
        impressions=1000,
        clicks=130,
    )
    
    test = ABTest(
        id="TEST-005",
        name="结果报告测试",
        product_id="PROD-001",
        control_variant=control,
        treatment_variants=[treatment],
    )
    
    test.complete(winner_id="VAR-B")
    
    result = ABTestResult.from_test(test)
    
    assert result.test_id == "TEST-005"
    assert result.winner_variant == "实验组"
    assert len(result.recommendations) > 0