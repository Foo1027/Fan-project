"""
内容模型测试
"""

import pytest
from src.models.content import ContentPiece, ContentSet, ContentType, ContentStyle


def test_content_piece_creation():
    """测试内容片段创建"""
    content = ContentPiece(
        id="CONTENT-001",
        type=ContentType.HEADLINE,
        style=ContentStyle.MARKETING,
        text="限时特惠！",
        product_id="PROD-001",
    )
    
    assert content.id == "CONTENT-001"
    assert content.type == ContentType.HEADLINE
    assert content.style == ContentStyle.MARKETING
    assert content.text == "限时特惠！"


def test_content_ctr_calculation():
    """测试点击率计算"""
    content = ContentPiece(
        id="CONTENT-002",
        type=ContentType.SLOGAN,
        style=ContentStyle.MARKETING,
        text="测试标语",
        product_id="PROD-001",
        impressions=1000,
        clicks=50,
    )
    
    ctr = content.calculate_ctr()
    assert ctr == 0.05
    assert content.ctr == 0.05


def test_content_metrics_update():
    """测试指标更新"""
    content = ContentPiece(
        id="CONTENT-003",
        type=ContentType.DESCRIPTION,
        style=ContentStyle.STORY,
        text="测试描述",
        product_id="PROD-001",
    )
    
    content.update_metrics(impressions=500, clicks=25, conversions=5)
    
    assert content.impressions == 500
    assert content.clicks == 25
    assert content.conversions == 5
    assert content.ctr == 0.05


def test_content_set_creation():
    """测试内容集合创建"""
    content_set = ContentSet(
        id="SET-001",
        product_id="PROD-001",
        name="测试内容集合",
        primary_style=ContentStyle.MARKETING,
    )
    
    assert content_set.id == "SET-001"
    assert content_set.product_id == "PROD-001"
    assert content_set.primary_style == ContentStyle.MARKETING


def test_content_set_with_pieces():
    """测试包含内容片段的集合"""
    headline = ContentPiece(
        id="HEAD-001",
        type=ContentType.HEADLINE,
        style=ContentStyle.MARKETING,
        text="主标题",
        product_id="PROD-001",
        impressions=1000,
        clicks=100,
    )
    
    slogan1 = ContentPiece(
        id="SLOGAN-001",
        type=ContentType.SLOGAN,
        style=ContentStyle.MARKETING,
        text="标语1",
        product_id="PROD-001",
        impressions=800,
        clicks=80,
    )
    
    slogan2 = ContentPiece(
        id="SLOGAN-002",
        type=ContentType.SLOGAN,
        style=ContentStyle.MARKETING,
        text="标语2",
        product_id="PROD-001",
        impressions=800,
        clicks=120,
    )
    
    content_set = ContentSet(
        id="SET-002",
        product_id="PROD-001",
        name="完整内容集合",
        headline=headline,
        slogans=[slogan1, slogan2],
    )
    
    # 计算整体指标
    content_set.calculate_overall_metrics()
    
    assert content_set.total_impressions == 2600  # 1000 + 800 + 800
    assert content_set.total_clicks == 300  # 100 + 80 + 120
    assert content_set.overall_ctr == 300 / 2600


def test_best_performing_content():
    """测试获取表现最好的内容"""
    slogan1 = ContentPiece(
        id="SLOGAN-001",
        type=ContentType.SLOGAN,
        style=ContentStyle.MARKETING,
        text="标语1",
        product_id="PROD-001",
        impressions=100,
        clicks=10,  # CTR = 10%
    )
    slogan1.calculate_ctr()
    
    slogan2 = ContentPiece(
        id="SLOGAN-002",
        type=ContentType.SLOGAN,
        style=ContentStyle.MARKETING,
        text="标语2",
        product_id="PROD-001",
        impressions=100,
        clicks=20,  # CTR = 20%
    )
    slogan2.calculate_ctr()
    
    content_set = ContentSet(
        id="SET-003",
        product_id="PROD-001",
        name="测试集合",
        slogans=[slogan1, slogan2],
    )
    
    best = content_set.get_best_performing("ctr")
    assert best is not None
    assert best.id == "SLOGAN-002"


def test_content_set_to_dict():
    """测试内容集合导出为字典"""
    headline = ContentPiece(
        id="HEAD-001",
        type=ContentType.HEADLINE,
        style=ContentStyle.MARKETING,
        text="主标题文本",
        product_id="PROD-001",
    )
    
    content_set = ContentSet(
        id="SET-004",
        product_id="PROD-001",
        name="导出测试",
        headline=headline,
        primary_style=ContentStyle.MARKETING,
    )
    
    data = content_set.to_dict()
    
    assert data["id"] == "SET-004"
    assert data["headline"] == "主标题文本"
    assert data["style"] == "marketing"